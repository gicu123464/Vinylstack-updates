const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const { autoUpdater } = require('electron-updater');
const { spawn } = require('child_process');
let listenServerProcess = null;
const path = require('path');
const os = require('os');
const fs = require('fs');
const https = require('https');
const { Store } = require('./store');

// This is a desktop music player; allow a stream resolved after the user's
// click to begin playback even after the yt-dlp network request has completed.
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

let mainWindow;
let store;
let updateState = { status: 'idle', currentVersion: app.getVersion(), version: null, percent: 0, error: null };

function publishUpdateState(next) {
  updateState = { ...updateState, ...next };
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('updates:status', updateState);
}

function configureUpdater() {
  autoUpdater.autoDownload = false;
  autoUpdater.autoInstallOnAppQuit = false;
  autoUpdater.on('checking-for-update', () => publishUpdateState({ status: 'checking', error: null, percent: 0 }));
  autoUpdater.on('update-available', (info) => {
    publishUpdateState({ status: 'available', version: info.version, error: null });
    if (store.get('settings').autoUpdate) autoUpdater.downloadUpdate().catch(() => {});
  });
  autoUpdater.on('update-not-available', (info) => publishUpdateState({ status: 'current', version: info.version, error: null, percent: 0 }));
  autoUpdater.on('download-progress', (progress) => publishUpdateState({ status: 'downloading', percent: Math.max(0, Math.min(100, Math.round(progress.percent || 0))) }));
  autoUpdater.on('update-downloaded', async (info) => {
    publishUpdateState({ status: 'downloaded', version: info.version, percent: 100, error: null });
    if (!mainWindow || mainWindow.isDestroyed()) return;
    const choice = await dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: 'Vinylstack is ready to update',
      message: `Vinylstack ${info.version} is ready to install.`,
      detail: 'Restart now to finish the update, or keep listening and restart later from Settings.',
      buttons: ['Restart now', 'Later'],
      defaultId: 0,
      cancelId: 1,
      noLink: true
    });
    if (choice.response === 0) autoUpdater.quitAndInstall(true, true);
  });
  autoUpdater.on('error', (error) => publishUpdateState({ status: 'error', error: error.message || 'Could not check for updates.' }));
}

// ---------------------------------------------------------------------------
// yt-dlp / ffmpeg helpers
// ---------------------------------------------------------------------------

// GUI-launched apps (double-clicked, or launched via winget/Start Menu/Finder)
// often get a slimmer PATH than a terminal does, so common install locations
// are appended defensively. This never removes anything from the real PATH.
const EXTRA_PATHS = process.platform === 'win32'
  ? [
      path.join(os.homedir(), 'AppData', 'Local', 'Microsoft', 'WinGet', 'Links'),
      path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Python', 'Scripts'),
      path.join(os.homedir(), 'AppData', 'Roaming', 'Python', 'Scripts'),
      path.join(os.homedir(), 'scoop', 'shims'),
      'C:\\ProgramData\\chocolatey\\bin'
    ]
  : [
      '/opt/homebrew/bin',
      '/usr/local/bin',
      '/usr/local/opt/yt-dlp/bin',
      path.join(os.homedir(), '.local', 'bin'),
      path.join(os.homedir(), 'Library', 'Python', '3.11', 'bin'),
      path.join(os.homedir(), 'Library', 'Python', '3.12', 'bin'),
      '/usr/bin',
      '/bin'
    ];

function buildEnv() {
  const sep = process.platform === 'win32' ? ';' : ':';
  const current = (process.env.PATH || process.env.Path || '').split(sep).filter(Boolean);
  const merged = [...new Set([...current, ...EXTRA_PATHS])].join(sep);
  return { ...process.env, PATH: merged };
}

// Runs a binary and collects stdout; rejects with stderr on non-zero exit.
// Args are always passed as an array (never a shell string, so nothing here
// is vulnerable to injection) — `shell:true` on Windows only changes how the
// executable itself is *located* (PATHEXT/.cmd resolution), not how args are parsed.
function run(bin, args, { onLine, timeoutMs = 120_000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, {
      windowsHide: true,
      // Do not use a shell here. On Windows, shell=true causes yt-dlp's
      // `ytsearch...:multi word query` argument to be split into separate
      // arguments, which makes yt-dlp interpret words such as `Park` as URLs.
      shell: false,
      env: buildEnv()
    });
    let stdout = '';
    let stderr = '';
    let settled = false;
    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      child.kill();
      reject(new Error(`Request timed out after ${Math.round(timeoutMs / 1000)} seconds.`));
    }, timeoutMs);
    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
      if (onLine) {
        const lines = chunk.toString().split('\n').filter(Boolean);
        lines.forEach(onLine);
      }
    });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    child.on('error', (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      reject(new Error(`${bin} not found or failed to start: ${err.message}`));
    });
    child.on('close', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (code === 0) resolve(stdout);
      else reject(new Error(stderr.trim() || `${bin} exited with code ${code}`));
    });
  });
}

function ytdlpBin() {
  const settings = store?.get('settings');
  if (settings && settings.ytdlpPath) return settings.ytdlpPath;
  if (process.platform === 'win32') {
    const bundled = path.join(process.resourcesPath, 'yt-dlp.exe');
    if (fs.existsSync(bundled)) return bundled;
    return 'yt-dlp.exe';
  }
  return 'yt-dlp';
}

function ffmpegBin() {
  const settings = store?.get('settings');
  if (settings && settings.ffmpegPath) return settings.ffmpegPath;
  if (process.platform === 'win32') {
    const bundled = path.join(process.resourcesPath, 'ffmpeg.exe');
    if (fs.existsSync(bundled)) return bundled;
    return 'ffmpeg.exe';
  }
  return 'ffmpeg';
}

// Extra yt-dlp args that point it at a manually-located ffmpeg, so downloads
// still work even when ffmpeg isn't on PATH but the user pointed us at it.
function ffmpegLocationArgs() {
  const settings = store?.get('settings');
  if (settings && settings.ffmpegPath) return ['--ffmpeg-location', settings.ffmpegPath];
  if (process.platform === 'win32') {
    const bundled = path.join(process.resourcesPath, 'ffmpeg.exe');
    if (fs.existsSync(bundled)) return ['--ffmpeg-location', path.dirname(bundled)];
  }
  return [];
}

async function checkBinaries() {
  const result = { ytdlp: false, ffmpeg: false, ytdlpVersion: null, ffmpegVersion: null, ytdlpError: null, ffmpegError: null };
  try {
    const v = await run(ytdlpBin(), ['--version']);
    result.ytdlp = true;
    result.ytdlpVersion = v.trim();
  } catch (err) { result.ytdlpError = err.message; }
  try {
    const v = await run(ffmpegBin(), ['-version']);
    result.ffmpeg = true;
    result.ffmpegVersion = v.split('\n')[0];
  } catch (err) { result.ffmpegError = err.message; }
  return result;
}

function parseFlatEntry(json) {
  const id = json.id || (typeof json.url === 'string' ? json.url.match(/[?&]v=([^&]+)/)?.[1] : null);
  return {
    id,
    title: json.title || 'Unknown title',
    artist: json.artist || (Array.isArray(json.artists) ? json.artists.join(', ') : null) || json.uploader || json.channel || 'Unknown artist',
    duration: json.duration || 0,
    thumbnail: json.thumbnail || (Array.isArray(json.thumbnails) && json.thumbnails.length
      ? json.thumbnails[json.thumbnails.length - 1].url : null),
    url: `https://www.youtube.com/watch?v=${json.id}`
  };
}

async function ytImportPlaylist(playlistUrl) {
  let parsed;
  try { parsed = new URL(String(playlistUrl || '').trim()); } catch (_) { throw new Error('Enter a valid YouTube Music playlist link.'); }
  if (!['music.youtube.com', 'youtube.com', 'www.youtube.com'].includes(parsed.hostname) || !parsed.pathname.includes('playlist') || !parsed.searchParams.has('list')) {
    throw new Error('Use a public YouTube Music playlist link.');
  }
  const out = await run(ytdlpBin(), [
    '--dump-single-json', '--flat-playlist', '--playlist-end', '500', '--no-warnings', parsed.toString()
  ]);
  let data;
  try { data = JSON.parse(out.trim().split('\n').pop()); } catch (_) { throw new Error('Could not read the playlist returned by yt-dlp.'); }
  const tracks = (data.entries || []).map(parseFlatEntry).filter((track) => track.id && track.title);
  if (!tracks.length) throw new Error('No tracks were found. The playlist may be private or unavailable.');
  return { name: data.title || 'Imported YouTube Music playlist', tracks };
}

function isVideoStyleResult(json) {
  const title = String(json.title || '').toLowerCase();
  const live = String(json.live_status || '').toLowerCase();
  return ['is_live', 'is_upcoming', 'was_live'].includes(live) ||
    /\b(official\s+)?(music\s+)?video\b|\blyric(s)?\s+video\b|\bvisuali[sz]er\b|\b(full\s+)?(live\s+)?(concert|performance|set)\b|\bofficial\s+video\b/.test(title);
}

const searchCache = new Map();
const searchInFlight = new Map();
async function ytSearch(query, limit = 20, options = {}) {
  const cacheKey = JSON.stringify([String(query).trim().toLowerCase(), Number(limit) || 20, !!options.excludeVideos]);
  const cached = searchCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.results;
  if (searchInFlight.has(cacheKey)) return searchInFlight.get(cacheKey);
  const request = ytSearchUncached(query, limit, options).then((results) => {
    searchCache.set(cacheKey, { results, expiresAt: Date.now() + 90_000 });
    while (searchCache.size > 40) searchCache.delete(searchCache.keys().next().value);
    return results;
  }).finally(() => searchInFlight.delete(cacheKey));
  searchInFlight.set(cacheKey, request);
  return request;
}

async function ytSearchUncached(query, limit = 20, options = {}) {
  const resultLimit = Math.max(1, Number(limit) || 20);
  const fetchLimit = options.excludeVideos ? Math.min(100, resultLimit * 3) : resultLimit;
  const results = [];
  await run(ytdlpBin(), [
    `ytsearch${fetchLimit}:${query}`,
    '--flat-playlist',
    '--dump-json',
    '--no-warnings',
    '--socket-timeout', '8',
    '--retries', '1',
    '--extractor-retries', '2'
  ], {
    timeoutMs: 45_000,
    onLine: (line) => {
      try {
        const json = JSON.parse(line);
        if (json.id && results.length < resultLimit && !(options.excludeVideos && isVideoStyleResult(json))) results.push(parseFlatEntry(json));
      } catch (_) { /* ignore non-JSON lines */ }
    }
  });
  return results;
}

async function ytResolveStream(videoIdOrUrl) {
  const url = videoIdOrUrl.startsWith('http') ? videoIdOrUrl : `https://www.youtube.com/watch?v=${videoIdOrUrl}`;
  const quality = store?.get('settings')?.audioQuality || 'medium';
  const format = quality === 'low' ? 'worstaudio/bestaudio' : quality === 'high' ? 'bestaudio' : 'bestaudio[abr<=160]/bestaudio';
  const out = await run(ytdlpBin(), [
    '-f', format,
    '-j',
    '--no-playlist',
    '--retries', '2',
    '--extractor-retries', '2',
    '--fragment-retries', '2',
    '--socket-timeout', '10',
    '--no-warnings',
    url
  ], { timeoutMs: 40_000 });
  const json = JSON.parse(out.trim().split('\n').pop());
  return {
    id: json.id,
    title: json.title,
    artist: json.uploader || json.channel || 'Unknown artist',
    duration: json.duration || 0,
    thumbnail: json.thumbnail,
    streamUrl: json.url
  };
}

async function ytDownload(videoIdOrUrl, destDir, format) {
  const url = videoIdOrUrl.startsWith('http') ? videoIdOrUrl : `https://www.youtube.com/watch?v=${videoIdOrUrl}`;
  if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
  const outTemplate = path.join(destDir, '%(title).180B - %(artist,creator,uploader)s.%(ext)s');
  const output = await run(ytdlpBin(), [
    '-x',
    '--audio-format', format || 'mp3',
    '--audio-quality', '0',
    '--embed-thumbnail',
    '--add-metadata',
    '--windows-filenames',
    '--print', 'after_move:filepath',
    ...ffmpegLocationArgs(),
    '-o', outTemplate,
    '--no-warnings',
    url
  ], { timeoutMs: 30 * 60_000 });
  const filePath = output.trim().split(/\r?\n/).filter(Boolean).pop();
  if (!filePath || !fs.existsSync(filePath)) throw new Error('yt-dlp completed but the named audio file could not be found.');
  return filePath;
}

// ---------------------------------------------------------------------------
// Lyrics (lrclib.net — free, no key, synced + plain lyrics)
// ---------------------------------------------------------------------------

function httpsGetJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Vinylstack desktop app' } }, (res) => {
      if (res.statusCode && res.statusCode >= 400) {
        res.resume();
        return reject(new Error(`Lyrics lookup failed (${res.statusCode})`));
      }
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch (err) { reject(err); }
      });
    }).on('error', reject);
  });
}

async function fetchLyrics(title, artist, duration) {
  const params = new URLSearchParams({ track_name: title, artist_name: artist || '' });
  if (duration) params.set('duration', String(Math.round(duration)));
  const results = await httpsGetJson(`https://lrclib.net/api/search?${params.toString()}`);
  if (!Array.isArray(results) || results.length === 0) return null;
  const best = results[0];
  return {
    synced: best.syncedLyrics || null,
    plain: best.plainLyrics || null,
    source: 'lrclib.net'
  };
}

// ---------------------------------------------------------------------------
// Window + IPC wiring
// ---------------------------------------------------------------------------


function startLocalListenServer() {
  if (process.env.VINYLSTACK_NO_LISTEN_SERVER === '1') return;
  const script = path.join(__dirname, 'listen-server.js');
  try {
    listenServerProcess = spawn(process.execPath, [script], {
      env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', PORT: process.env.VINYLSTACK_LISTEN_PORT || '8787' },
      windowsHide: true,
      stdio: 'ignore'
    });
    listenServerProcess.on('error', () => { listenServerProcess = null; });
    listenServerProcess.on('exit', () => { listenServerProcess = null; });
  } catch (_) { listenServerProcess = null; }
}

function stopLocalListenServer() {
  if (!listenServerProcess) return;
  try { listenServerProcess.kill(); } catch (_) {}
  listenServerProcess = null;
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 720,
    minHeight: 520,
    backgroundColor: '#14171c',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false // preload needs fs-free node APIs only via IPC; renderer itself stays sandboxed from node
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));
}

app.whenReady().then(() => {
  // Keep the player chrome free of Electron's default File/Edit/View menu.
  Menu.setApplicationMenu(null);
  const userDataDir = app.getPath('userData');
  store = new Store(path.join(userDataDir, 'vinylstack-data'));

  const settings = store.get('settings');
  let settingsChanged = false;
  if (typeof settings.autoUpdate !== 'boolean') {
    settings.autoUpdate = false;
    settingsChanged = true;
  }
  if (!settings.downloadDir) {
    settings.downloadDir = path.join(userDataDir, 'downloads');
    settingsChanged = true;
  }
  if (settingsChanged) {
    store.set('settings', settings);
  }

  // --- store IPC ---
  ipcMain.handle('store:get', (_e, section) => store.get(section));
  ipcMain.handle('store:set', (_e, section, value) => store.set(section, value));

  // --- binaries ---
  ipcMain.handle('binaries:check', () => checkBinaries());

  // --- updates ---
  configureUpdater();
  ipcMain.handle('updates:getState', () => ({ ...updateState, autoUpdate: !!store.get('settings').autoUpdate }));
  ipcMain.handle('updates:check', async () => {
    if (!app.isPackaged) {
      publishUpdateState({ status: 'error', error: 'Update checks are available in the installed app.' });
      return false;
    }
    publishUpdateState({ status: 'checking', error: null, percent: 0 });
    try { await autoUpdater.checkForUpdates(); return true; }
    catch (error) { publishUpdateState({ status: 'error', error: error.message || 'Could not check for updates.' }); return false; }
  });
  ipcMain.handle('updates:download', async () => {
    try { await autoUpdater.downloadUpdate(); return true; }
    catch (error) { publishUpdateState({ status: 'error', error: error.message || 'Could not download the update.' }); return false; }
  });
  ipcMain.handle('updates:install', () => autoUpdater.quitAndInstall(true, true));
  ipcMain.handle('updates:setAuto', (_e, enabled) => {
    const current = store.get('settings');
    current.autoUpdate = !!enabled;
    store.set('settings', current);
    if (current.autoUpdate && app.isPackaged) autoUpdater.checkForUpdates().catch(() => {});
    return current.autoUpdate;
  });

  // --- yt-dlp ---
  ipcMain.handle('ytdlp:search', (_e, query, limit, options) => ytSearch(query, limit, options));
  ipcMain.handle('ytdlp:resolve', (_e, videoId) => ytResolveStream(videoId));
  ipcMain.handle('ytdlp:importPlaylist', (_e, url) => ytImportPlaylist(url));
  ipcMain.handle('ytdlp:download', async (_e, videoId, meta) => {
    const settings = store.get('settings');
    const filePath = await ytDownload(videoId, settings.downloadDir, settings.audioFormat);
    const library = store.get('library');
    const entry = {
      id: videoId,
      title: meta.title,
      artist: meta.artist,
      duration: meta.duration,
      thumbnail: meta.thumbnail,
      filePath,
      addedAt: Date.now()
    };
    const next = [entry, ...library.filter((t) => t.id !== videoId)];
    store.set('library', next);
    return entry;
  });

  // --- lyrics ---
  // Lyrics are an optional companion feature. Upstream outages (including
  // LRCLIB 503s) should resolve as "not found" instead of surfacing as an
  // unhandled IPC rejection in the user's command window.
  ipcMain.handle('lyrics:fetch', async (_e, title, artist, duration) => {
    try { return await fetchLyrics(title, artist, duration); }
    catch (_) { return null; }
  });

  // --- filesystem helpers ---
  ipcMain.handle('dialog:chooseDownloadDir', async () => {
    const res = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory', 'createDirectory'] });
    if (res.canceled || !res.filePaths[0]) return null;
    const settings = store.get('settings');
    settings.downloadDir = res.filePaths[0];
    store.set('settings', settings);
    return settings.downloadDir;
  });
  ipcMain.handle('shell:openPath', (_e, targetPath) => shell.openPath(targetPath));
  ipcMain.handle('dialog:locateBinary', async (_e, type) => {
    const res = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      title: type === 'ffmpeg' ? 'Locate your ffmpeg executable' : 'Locate your yt-dlp executable',
      filters: process.platform === 'win32' ? [{ name: 'Executable', extensions: ['exe'] }] : undefined
    });
    if (res.canceled || !res.filePaths[0]) return null;
    const settings = store.get('settings');
    if (type === 'ffmpeg') settings.ffmpegPath = res.filePaths[0];
    else settings.ytdlpPath = res.filePaths[0];
    store.set('settings', settings);
    return checkBinaries();
  });
  ipcMain.handle('library:removeFile', async (_e, trackId) => {
    const library = store.get('library');
    const entry = library.find((t) => t.id === trackId);
    if (entry?.filePath && fs.existsSync(entry.filePath)) {
      try { fs.unlinkSync(entry.filePath); } catch (_) {}
    }
    const next = library.filter((t) => t.id !== trackId);
    store.set('library', next);
    return next;
  });

  startLocalListenServer();
  createWindow();
  if (settings.autoUpdate && app.isPackaged) setTimeout(() => autoUpdater.checkForUpdates().catch(() => {}), 5000);
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', () => stopLocalListenServer());
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
