// Minimal protobuf codec for Metrolist's metroproto/listentogether.proto.
// Generated manually from the public schema so Vinylstack can speak the same
// binary protocol without pulling a large runtime into the renderer.

const te = new TextEncoder();
const td = new TextDecoder();

function varint(n) {
  let x = BigInt(n);
  if (x < 0n) x = (1n << 64n) + x;
  const out = [];
  do { let b = Number(x & 127n); x >>= 7n; if (x) b |= 128; out.push(b); } while (x);
  return out;
}
function readVarint(a, i) {
  let x = 0n, s = 0n;
  while (i < a.length) { const b = a[i++]; x |= BigInt(b & 127) << s; if (!(b & 128)) break; s += 7n; }
  return [x, i];
}
function bytes(v) { return v instanceof Uint8Array ? v : new Uint8Array(v || []); }
function utf8(v) { return te.encode(String(v ?? '')); }
function field(tag, wire, data) { return [...varint((tag << 3) | wire), ...data]; }
function str(tag, v) { return v == null || v === '' ? [] : field(tag, 2, [...varint(utf8(v).length), ...utf8(v)]); }
function raw(tag, v) { const b = bytes(v); return b.length ? field(tag, 2, [...varint(b.length), ...b]) : []; }
function bool(tag, v) { return v ? field(tag, 0, [1]) : []; }
function int64(tag, v) { return v == null || Number(v) === 0 ? [] : field(tag, 0, varint(BigInt(Math.trunc(v)))); }
function float(tag, v) { if (v == null || Number(v) === 0) return []; const b = new ArrayBuffer(4); new DataView(b).setFloat32(0, Number(v), true); return field(tag, 5, [...new Uint8Array(b)]); }
function msg(tag, v, enc) { if (!v) return []; const b = enc(v); return field(tag, 2, [...varint(b.length), ...b]); }
function repmsg(tag, arr, enc) { return (arr || []).flatMap(v => msg(tag, v, enc)); }

function parse(input) {
  const a = bytes(input), out = [];
  let i = 0;
  while (i < a.length) {
    let tag; [tag, i] = readVarint(a, i); tag = Number(tag);
    const num = tag >>> 3, wire = tag & 7;
    let value;
    if (wire === 0) [value, i] = readVarint(a, i);
    else if (wire === 2) { let n; [n, i] = readVarint(a, i); n = Number(n); value = a.slice(i, i + n); i += n; }
    else if (wire === 5) { value = a.slice(i, i + 4); i += 4; }
    else if (wire === 1) { value = a.slice(i, i + 8); i += 8; }
    else throw new Error(`Unsupported protobuf wire type ${wire}`);
    out.push({ num, wire, value });
  }
  return out;
}
function text(v) { return td.decode(v); }
function num(v) { return Number(v); }
function f32(v) { return new DataView(v.buffer, v.byteOffset, v.byteLength).getFloat32(0, true); }

export function encodeEnvelope(type, payload, compressed = false) {
  return Uint8Array.from([...str(1, type), ...raw(2, payload), ...bool(3, compressed)]);
}
export function decodeEnvelope(input) {
  const out = { type: '', payload: new Uint8Array(), compressed: false };
  for (const f of parse(input)) {
    if (f.num === 1 && f.wire === 2) out.type = text(f.value);
    else if (f.num === 2 && f.wire === 2) out.payload = f.value;
    else if (f.num === 3 && f.wire === 0) out.compressed = Boolean(num(f.value));
  }
  return out;
}

export function encodeTrack(t = {}) {
  return Uint8Array.from([
    ...str(1, t.id), ...str(2, t.title), ...str(3, t.artist), ...str(4, t.album),
    ...int64(5, (t.duration || 0) * 1000), ...str(6, t.thumbnail), ...str(7, t.suggestedBy)
  ]);
}
export function decodeTrack(input) {
  const t = {};
  for (const f of parse(input)) {
    if (f.num === 1) t.id = text(f.value); else if (f.num === 2) t.title = text(f.value); else if (f.num === 3) t.artist = text(f.value);
    else if (f.num === 4) t.album = text(f.value); else if (f.num === 5) t.duration = num(f.value) / 1000;
    else if (f.num === 6) t.thumbnail = text(f.value); else if (f.num === 7) t.suggestedBy = text(f.value);
  }
  return t;
}

function encodeUser(u = {}) { return Uint8Array.from([...str(1,u.userId||u.id), ...str(2,u.username), ...bool(3,u.isHost||u.host), ...bool(4,u.isConnected ?? true)]); }
function decodeUser(input) { const u={}; for(const f of parse(input)){if(f.num===1)u.userId=text(f.value);else if(f.num===2)u.username=text(f.value);else if(f.num===3)u.isHost=!!num(f.value);else if(f.num===4)u.isConnected=!!num(f.value);} return u; }

export function encodeRoomState(s = {}) {
  const users = (s.users || []).map(u => ({...u}));
  return Uint8Array.from([
    ...str(1,s.roomCode), ...str(2,s.hostId), ...repmsg(3,users,encodeUser), ...msg(4,s.currentTrack,encodeTrack),
    ...bool(5,s.isPlaying), ...int64(6,(s.position||0)*1000), ...int64(7,s.lastUpdate||0), ...float(8,s.volume),
    ...repmsg(9,s.queue||[],encodeTrack), ...int64(10,s.revision||0)
  ]);
}
export function decodeRoomState(input) {
  const s={users:[],queue:[]}; for(const f of parse(input)){
    if(f.num===1)s.roomCode=text(f.value); else if(f.num===2)s.hostId=text(f.value); else if(f.num===3)s.users.push(decodeUser(f.value));
    else if(f.num===4)s.currentTrack=decodeTrack(f.value); else if(f.num===5)s.isPlaying=!!num(f.value); else if(f.num===6)s.position=num(f.value)/1000;
    else if(f.num===7)s.lastUpdate=num(f.value); else if(f.num===8)s.volume=f32(f.value); else if(f.num===9)s.queue.push(decodeTrack(f.value)); else if(f.num===10)s.revision=num(f.value);
  } return s;
}

const schemas = {
  client_capabilities: x => Uint8Array.from([...bool(1,x.supportsProtobuf),...bool(2,x.supportsCompression),...str(3,x.clientVersion)]),
  ping: x => Uint8Array.from([...int64(1,x.clientTime),...int64(2,x.sequence)]),
  pong: () => new Uint8Array(),
  request_sync: () => new Uint8Array(),
  create_room: x => Uint8Array.from(str(1,x.username)),
  join_room: x => Uint8Array.from([...str(1,x.roomCode),...str(2,x.username)]),
  leave_room: () => new Uint8Array(),
  approve_join: x => Uint8Array.from(str(1,x.userId)),
  reject_join: x => Uint8Array.from([...str(1,x.userId),...str(2,x.reason)]),
  playback_action: x => Uint8Array.from([...str(1,x.action),...str(2,x.trackId),...int64(3,(x.position||0)*1000),...msg(4,x.trackInfo,encodeTrack),...bool(5,x.insertNext),...repmsg(6,x.queue||[],encodeTrack),...str(7,x.queueTitle),...float(8,x.volume),...int64(9,x.serverTime||0),...int64(10,x.revision||0),...int64(11,x.capturedAtServerTime||0)]),
  buffer_ready: x => Uint8Array.from(str(1,x.trackId)),
  kick_user: x => Uint8Array.from([...str(1,x.userId),...str(2,x.reason)]),
  transfer_host: x => Uint8Array.from(str(1,x.newHostId)),
  suggest_track: x => Uint8Array.from(msg(1,x.trackInfo,encodeTrack)),
  approve_suggestion: x => Uint8Array.from(str(1,x.suggestionId)),
  reject_suggestion: x => Uint8Array.from([...str(1,x.suggestionId),...str(2,x.reason)]),
  reconnect: x => Uint8Array.from(str(1,x.sessionToken))
};

export function encodePayload(type, payload) { return schemas[type] ? schemas[type](payload || {}) : new Uint8Array(); }

export function decodePayload(type, input) {
  const out={};
  for(const f of parse(input)){
    if(type==='room_created'){if(f.num===1)out.roomCode=text(f.value);else if(f.num===2)out.userId=text(f.value);else if(f.num===3)out.sessionToken=text(f.value);}
    else if(type==='join_request'){if(f.num===1)out.userId=text(f.value);else if(f.num===2)out.username=text(f.value);}
    else if(type==='join_approved'){if(f.num===1)out.roomCode=text(f.value);else if(f.num===2)out.userId=text(f.value);else if(f.num===3)out.sessionToken=text(f.value);else if(f.num===4)out.state=decodeRoomState(f.value);}
    else if(type==='join_rejected'){if(f.num===1)out.reason=text(f.value);}
    else if(type==='user_joined'){if(f.num===1)out.userId=text(f.value);else if(f.num===2)out.username=text(f.value);}
    else if(type==='user_left'||type==='user_disconnected'||type==='user_reconnected'){if(f.num===1)out.userId=text(f.value);else if(f.num===2)out.username=text(f.value);}
    else if(type==='playback_action'||type==='sync_playback'){if(f.num===1)out.action=text(f.value);else if(f.num===2)out.trackId=text(f.value);else if(f.num===3)out.position=num(f.value)/1000;else if(f.num===4)out.trackInfo=decodeTrack(f.value);else if(f.num===5)out.insertNext=!!num(f.value);else if(f.num===6){out.queue ||= [];out.queue.push(decodeTrack(f.value));}else if(f.num===7)out.queueTitle=text(f.value);else if(f.num===8)out.volume=f32(f.value);else if(f.num===9)out.serverTime=num(f.value);else if(f.num===10)out.revision=num(f.value);else if(f.num===11)out.capturedAtServerTime=num(f.value);}
    else if(type==='sync_state'){if(f.num===1)out.currentTrack=decodeTrack(f.value);else if(f.num===2)out.isPlaying=!!num(f.value);else if(f.num===3)out.position=num(f.value)/1000;else if(f.num===4)out.lastUpdate=num(f.value);else if(f.num===5){out.queue ||= [];out.queue.push(decodeTrack(f.value));}else if(f.num===6)out.volume=f32(f.value);else if(f.num===7)out.revision=num(f.value);}
    else if(type==='pong'){if(f.num===1)out.clientTime=num(f.value);else if(f.num===2)out.serverReceiveTime=num(f.value);else if(f.num===3)out.serverSendTime=num(f.value);else if(f.num===4)out.sequence=num(f.value);}
    else if(type==='reconnected'){if(f.num===1)out.roomCode=text(f.value);else if(f.num===2)out.userId=text(f.value);else if(f.num===3)out.state=decodeRoomState(f.value);else if(f.num===4)out.isHost=!!num(f.value);}
    else if(type==='server_capabilities'){if(f.num===1)out.supportsProtobuf=!!num(f.value);else if(f.num===2)out.supportsCompression=!!num(f.value);else if(f.num===3)out.serverVersion=text(f.value);}
    else if(type==='error'){if(f.num===1)out.code=text(f.value);else if(f.num===2)out.message=text(f.value);}
    else if(type==='host_changed'){if(f.num===1)out.newHostId=text(f.value);else if(f.num===2)out.newHostName=text(f.value);}
    else if(type==='kicked'){if(f.num===1)out.reason=text(f.value);}
    else if(type==='buffer_wait'){if(f.num===1)out.trackId=text(f.value);else if(f.num===2){out.waitingFor ||= [];out.waitingFor.push(text(f.value));}}
    else if(type==='buffer_complete'){if(f.num===1)out.trackId=text(f.value);}
    else if(type==='suggestion_received'){if(f.num===1)out.suggestionId=text(f.value);else if(f.num===2)out.fromUserId=text(f.value);else if(f.num===3)out.fromUsername=text(f.value);else if(f.num===4)out.trackInfo=decodeTrack(f.value);}
    else if(type==='suggestion_approved'){if(f.num===1)out.suggestionId=text(f.value);else if(f.num===2)out.trackInfo=decodeTrack(f.value);}
    else if(type==='suggestion_rejected'){if(f.num===1)out.suggestionId=text(f.value);else if(f.num===2)out.reason=text(f.value);}
  }
  return out;
}

export function roomStateFromApp(state) {
  return {
    roomCode: state.listenTogether.roomCode || '', hostId: state.listenTogether.hostId || '',
    users: state.listenTogether.users || [], currentTrack: state.nowPlaying ? { ...state.nowPlaying, duration: state.duration || state.nowPlaying.duration || 0 } : null,
    isPlaying: !!state.isPlaying, position: state.currentTime || 0, lastUpdate: Date.now(), volume: state.volume || 1,
    queue: (state.queue?.trackIds || []).map(id => getTrackSafe(state, id)).filter(Boolean)
  };
}
function getTrackSafe(s,id){ return (s.trackRegistry && s.trackRegistry[id]) || null; }
