// player.js — one <audio> element and one Web Audio filter chain, reused for
// both streamed (yt-dlp) and downloaded (local file) tracks, so playback,
// volume, and the equalizer behave identically regardless of source.

import { patch, tick } from './state.js';

export const EQ_BANDS_HZ = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

export const EQ_PRESETS = {
  flat:    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  bass:    [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
  treble:  [0, 0, 0, 0, 0, 1, 2, 4, 5, 6],
  vocal:   [-2, -1, 0, 2, 4, 4, 2, 0, -1, -2],
  rock:    [4, 3, 2, 0, -1, 0, 2, 3, 4, 4],
  pop:     [-1, 1, 3, 3, 1, -1, -1, 1, 2, 2],
  electronic: [4, 3, 0, -2, -3, 0, 1, 2, 4, 5]
};

let audioEl = null;
let ctx = null;
let sourceNode = null;
let filters = [];
let analyser = null;
let frequencyData = null;
let waveformData = null;
let visualizerResponsiveness = 75;
let endedCallback = null;
let progressCallback = null;
let errorCallback = null;
let pendingSeekSeconds = 0;

export function init(el) {
  audioEl = el;
  // HTMLMediaElement preserves pitch by default in Chromium. Varispeed should
  // behave like changing tape speed, so explicitly disable pitch correction.
  if ('preservesPitch' in audioEl) audioEl.preservesPitch = false;
  if ('mozPreservesPitch' in audioEl) audioEl.mozPreservesPitch = false;
  if ('webkitPreservesPitch' in audioEl) audioEl.webkitPreservesPitch = false;
  audioEl.addEventListener('timeupdate', () => {
    tick({ currentTime: audioEl.currentTime });
    if (progressCallback) progressCallback(audioEl.currentTime, audioEl.duration);
  });
  audioEl.addEventListener('loadedmetadata', () => {
    if (audioEl.duration && isFinite(audioEl.duration)) {
      patch({ duration: audioEl.duration });
      if (pendingSeekSeconds > 0) {
        audioEl.currentTime = Math.min(pendingSeekSeconds, Math.max(0, audioEl.duration - 1));
        pendingSeekSeconds = 0;
      }
    }
  });
  audioEl.addEventListener('ended', () => {
    patch({ isPlaying: false });
    if (endedCallback) endedCallback();
  });
  audioEl.addEventListener('error', () => {
    patch({ isPlaying: false });
    if (errorCallback) errorCallback();
  });
}

// Web Audio graph is created lazily on first user-gesture play(), as browsers
// require an AudioContext to start from a gesture.
function ensureGraph() {
  if (ctx) return;
  ctx = new (window.AudioContext || window.webkitAudioContext)();
  sourceNode = ctx.createMediaElementSource(audioEl);
  filters = EQ_BANDS_HZ.map((freq) => {
    const f = ctx.createBiquadFilter();
    f.type = 'peaking';
    f.frequency.value = freq;
    f.Q.value = 1.1;
    f.gain.value = 0;
    return f;
  });
  // chain: source -> filters -> analyser -> destination
  let node = sourceNode;
  for (const f of filters) { node.connect(f); node = f; }
  analyser = ctx.createAnalyser();
  analyser.fftSize = 32768;
  // Keep measured values raw; response smoothing is applied only to the drawn
  // bars so changing the UI response never changes the underlying readings.
  analyser.smoothingTimeConstant = 0;
  analyser.minDecibels = -100;
  analyser.maxDecibels = 0;
  allocateVisualizerBuffers();
  node.connect(analyser);
  analyser.connect(ctx.destination);
}

// Returns the current spectrum for visual effects without changing the signal.
export function getFrequencyData() {
  if (!analyser || !frequencyData) return null;
  analyser.getFloatFrequencyData(frequencyData);
  return frequencyData;
}

export function getSpectrumInfo() {
  if (!analyser || !frequencyData) return null;
  analyser.getFloatFrequencyData(frequencyData);
  return { data: frequencyData, sampleRate: ctx.sampleRate, fftSize: analyser.fftSize };
}

export function getWaveformInfo() {
  if (!analyser || !waveformData) return null;
  analyser.getFloatTimeDomainData(waveformData);
  const integrationSamples = Math.min(waveformData.length, Math.max(1, Math.round(ctx.sampleRate * 0.05)));
  const start = waveformData.length - integrationSamples;
  let sumSquares = 0;
  for (let i = start; i < waveformData.length; i += 1) {
    const sample = waveformData[i];
    sumSquares += sample * sample;
  }
  const rms = Math.sqrt(sumSquares / integrationSamples);
  return { rmsDbfs: rms > 0 ? 20 * Math.log10(rms) : -Infinity };
}

export function setVisualizerResponsiveness(value) {
  visualizerResponsiveness = Math.max(0, Math.min(100, Number(value) || 0));
}

export function getVisualizerResponsiveness() { return visualizerResponsiveness; }

function allocateVisualizerBuffers() {
  if (!analyser) return;
  frequencyData = new Float32Array(analyser.frequencyBinCount);
  waveformData = new Float32Array(analyser.fftSize);
}

export function loadSource(url, _duration = 0, startSeconds = 0) {
  pendingSeekSeconds = Math.max(0, Number(startSeconds) || 0);
  audioEl.src = url;
  audioEl.currentTime = 0;
}

export async function play() {
  try {
    ensureGraph();
    if (ctx.state === 'suspended') await ctx.resume();
    await audioEl.play();
    return true;
  } catch (error) {
    patch({ isPlaying: false });
    return false;
  }
}

export function pause() {
  audioEl.pause();
}

export function seek(seconds) {
  audioEl.currentTime = Math.max(0, Math.min(seconds, audioEl.duration || seconds));
}

export function setVolume(v) {
  audioEl.volume = Math.max(0, Math.min(1, v));
}

export function setPlaybackRate(rate) {
  if (!audioEl) return;
  const value = Math.max(0.5, Math.min(2, rate));
  audioEl.playbackRate = value;
  audioEl.defaultPlaybackRate = value;
  // Reassert on each change for Chromium versions exposing prefixed property.
  if ('preservesPitch' in audioEl) audioEl.preservesPitch = false;
  if ('mozPreservesPitch' in audioEl) audioEl.mozPreservesPitch = false;
  if ('webkitPreservesPitch' in audioEl) audioEl.webkitPreservesPitch = false;
}

export function applyEqualizer({ bands }) {
  ensureGraph();
  if (!filters.length || !bands) return;
  filters.forEach((f, i) => { f.gain.value = bands[i] ?? 0; });
}

export function onEnded(cb) {
  endedCallback = cb;
}

export function onProgress(cb) { progressCallback = cb; }
export function onError(cb) { errorCallback = cb; }
