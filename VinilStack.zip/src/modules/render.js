import { state, patch, getTrack } from './state.js';
import * as actions from './actions.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function formatTime(seconds) {
  if (!seconds || !isFinite(seconds)) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

const FALLBACK_ART =
  'data:image/svg+xml;utf8,' + encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48"><rect width="48" height="48" fill="#242a35"/><circle cx="24" cy="24" r="8" fill="#565b66"/></svg>`
  );

// ---------------------------------------------------------------------------
// Track row builder — used by every list view so a row behaves identically
// whether it came from search, a playlist, favorites, or downloads.
// ---------------------------------------------------------------------------

function trackRow(track, { context = null } = {}) {
  const row = document.createElement('div');
  row.className = 'track-row' + (state.nowPlaying?.id === track.id ? ' playing' : '');

  const thumb = document.createElement('img');
  thumb.className = 'track-thumb';
  thumb.src = track.thumbnail || FALLBACK_ART;
  thumb.alt = '';
  thumb.loading = 'lazy';

  const info = document.createElement('div');
  info.className = 'track-info';
  info.innerHTML = `
    <div class="track-title"></div>
    <div class="track-artist"></div>
  `;
  info.querySelector('.track-title').textContent = track.title;
  info.querySelector('.track-artist').textContent = track.artist;

  const actionsEl = document.createElement('div');
  actionsEl.className = 'track-actions';

  const favBtn = iconButton(actions.isFavorite(track.id) ? '♥' : '♡', () => actions.toggleFavorite(track));
  favBtn.classList.toggle('on', actions.isFavorite(track.id));
  favBtn.title = 'Favorite';

  const addBtn = iconButton('+', () => actions.playNext(track));
  addBtn.title = 'Play next';

  const dlBtn = iconButton(actions.isDownloaded(track.id) ? '✓' : '⬇', () => {
    if (!actions.isDownloaded(track.id)) actions.downloadTrack(track);
  });
  dlBtn.title = actions.isDownloaded(track.id) ? 'Downloaded' : 'Download';
  if (actions.isDownloaded(track.id)) dlBtn.classList.add('on');

  actionsEl.append(favBtn, addBtn, dlBtn);

  if (context?.playlistId) {
    const removeBtn = iconButton('−', () => actions.removeFromPlaylist(context.playlistId, track.id));
    removeBtn.title = 'Remove from playlist';
    actionsEl.append(removeBtn);
  }
  if (context?.menu) {
    const menuBtn = iconButton('⋯', () => openPlaylistPicker(track));
    menuBtn.title = 'Add to playlist';
    actionsEl.append(menuBtn);
  }
  if (context?.downloadsView) {
    const removeBtn = iconButton('🗑', () => actions.removeFromLibrary(track.id));
    removeBtn.title = 'Delete download';
    actionsEl.append(removeBtn);
  }

  const duration = document.createElement('span');
  duration.className = 'track-duration';
  duration.textContent = formatTime(track.duration);
  actionsEl.append(duration);

  row.append(thumb, info, actionsEl);
  row.addEventListener('dblclick', () => actions.playTrack(track));
  row.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    openTrackContextMenu(track, event.clientX, event.clientY);
  });
  info.addEventListener('click', () => actions.playTrack(track));
  info.style.cursor = 'pointer';

  return row;
}

function openTrackContextMenu(track, x, y) {
  document.querySelector('.track-context-menu')?.remove();
  const menu = document.createElement('div');
  menu.className = 'track-context-menu';
  menu.setAttribute('role', 'menu');
  menu.setAttribute('aria-label', `Actions for ${track.title}`);
  const title = document.createElement('div');
  title.className = 'track-context-title';
  title.textContent = track.title;
  const add = document.createElement('button');
  add.type = 'button';
  add.setAttribute('role', 'menuitem');
  add.innerHTML = '<span aria-hidden="true">＋</span> Add to playlist';
  const closeMenu = () => {
    menu.remove();
    document.removeEventListener('pointerdown', dismiss, true);
    document.removeEventListener('keydown', dismiss, true);
  };
  add.addEventListener('click', () => { closeMenu(); openPlaylistPicker(track); });
  menu.append(title, add);
  document.body.appendChild(menu);
  const rect = menu.getBoundingClientRect();
  menu.style.left = `${Math.max(8, Math.min(x, window.innerWidth - rect.width - 8))}px`;
  menu.style.top = `${Math.max(8, Math.min(y, window.innerHeight - rect.height - 8))}px`;
  const dismiss = (event) => {
    if (event.type === 'keydown' && event.key !== 'Escape') return;
    if (event.type === 'pointerdown' && menu.contains(event.target)) return;
    closeMenu();
  };
  document.addEventListener('pointerdown', dismiss, true);
  document.addEventListener('keydown', dismiss, true);
  add.focus();
}

function iconButton(label, onClick) {
  const btn = document.createElement('button');
  btn.className = 'icon-btn';
  btn.textContent = label;
  btn.style.fontSize = '13px';
  btn.addEventListener('click', (e) => { e.stopPropagation(); onClick(); });
  return btn;
}

function trackList(tracks, opts = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'track-list';
  if (!tracks.length) {
    wrap.innerHTML = `<div class="empty-state">${opts.emptyMessage || 'Nothing here yet.'}</div>`;
    return wrap;
  }
  tracks.forEach((t) => wrap.appendChild(trackRow(t, opts)));
  return wrap;
}

function openPlaylistPicker(track) {
  document.querySelector('.playlist-picker')?.remove();
  const dialog = document.createElement('dialog');
  dialog.className = 'playlist-picker';
  const heading = document.createElement('h2'); heading.textContent = 'Add to playlist';
  const caption = document.createElement('p'); caption.textContent = track.title;
  const form = document.createElement('form');
  const label = document.createElement('label'); label.textContent = 'Choose a playlist';
  const select = document.createElement('select'); select.setAttribute('aria-label', 'Choose a playlist');
  state.playlists.forEach((playlist) => {
    const option = document.createElement('option'); option.value = playlist.id; option.textContent = playlist.name; select.appendChild(option);
  });
  const createOption = document.createElement('option'); createOption.value = '__new__'; createOption.textContent = 'Create a new playlist'; select.appendChild(createOption);
  const name = document.createElement('input'); name.type = 'text'; name.maxLength = 80; name.placeholder = 'New playlist name'; name.setAttribute('aria-label', 'New playlist name'); name.hidden = state.playlists.length > 0;
  select.addEventListener('change', () => { name.hidden = select.value !== '__new__'; if (!name.hidden) name.focus(); });
  if (!state.playlists.length) select.value = '__new__';
  label.appendChild(select);
  const buttons = document.createElement('div'); buttons.className = 'playlist-picker-actions';
  const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'btn'; cancel.textContent = 'Cancel'; cancel.addEventListener('click', () => dialog.close());
  const add = document.createElement('button'); add.type = 'submit'; add.className = 'btn primary'; add.textContent = 'Add song';
  buttons.append(cancel, add);
  form.append(label, name, buttons);
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    let playlist = state.playlists.find((item) => item.id === select.value);
    if (select.value === '__new__') {
      if (!name.value.trim()) { name.focus(); return; }
      playlist = actions.createPlaylist(name.value.trim());
    }
    if (!playlist) return;
    actions.addToPlaylist(playlist.id, track);
    dialog.close();
  });
  dialog.append(heading, caption, form);
  dialog.addEventListener('close', () => dialog.remove(), { once: true });
  document.body.appendChild(dialog);
  dialog.showModal();
  if (name.hidden) select.focus(); else name.focus();
}

// ---------------------------------------------------------------------------
// Views
// ---------------------------------------------------------------------------

function viewHeader(title, subtitle) {
  const el = document.createElement('div');
  el.className = 'view-header';
  el.innerHTML = `<div class="view-eyebrow"></div><h1 class="view-title"></h1><div class="view-subtitle"></div>`;
  el.querySelector('.view-eyebrow').textContent = `YOUR MUSIC / ${title}`;
  el.querySelector('.view-title').textContent = title;
  el.querySelector('.view-subtitle').textContent = subtitle || '';
  return el;
}

function quickPickCard(track) {
  const card = document.createElement('div');
  card.className = 'quick-pick-card';
  card.setAttribute('role', 'group');
  card.setAttribute('aria-label', track.title);
  const art = document.createElement('img');
  art.src = track.thumbnail || FALLBACK_ART;
  art.alt = '';
  art.loading = 'lazy';
  const info = document.createElement('span');
  info.className = 'quick-pick-info';
  const title = document.createElement('strong');
  title.textContent = track.title;
  const artist = document.createElement('small');
  artist.textContent = track.artist || 'Unknown artist';
  info.append(title, artist);
  const actionsEl = document.createElement('span');
  actionsEl.className = 'quick-pick-actions';
  const play = document.createElement('button');
  play.type = 'button';
  play.className = 'quick-pick-play';
  play.textContent = '▶';
  play.setAttribute('aria-label', `Play ${track.title}`);
  play.title = `Play ${track.title}`;
  play.addEventListener('click', () => actions.playTrack(track));
  const add = document.createElement('button');
  add.type = 'button'; add.className = 'quick-pick-add'; add.textContent = '+'; add.title = 'Add to playlist'; add.setAttribute('aria-label', `Add ${track.title} to playlist`);
  add.addEventListener('click', () => openPlaylistPicker(track));
  actionsEl.append(play, add);
  card.append(art, info, actionsEl);
  return card;
}

function renderHomeView(container) {
  const hour = new Date().getHours();
  const greeting = hour >= 5 && hour < 12 ? 'Good morning.' : hour >= 12 && hour < 17 ? 'Good afternoon.' : hour >= 17 && hour < 22 ? 'Good evening.' : 'Good night.';
  const homeHeader = viewHeader(greeting, 'Set the mood. Let the music do the rest.');
  homeHeader.classList.add('home-view-header');
  container.appendChild(homeHeader);

  const featuredTrack = state.nowPlaying || state.recents[0] || state.favorites.map((id) => getTrack(id)).find(Boolean) || state.library[0] || null;
  const hero = el('section', 'home-hero');
  const heroCopy = el('div', 'home-hero-copy');
  heroCopy.appendChild(el('div', 'home-hero-kicker', 'YOUR LISTENING SPACE'));
  heroCopy.appendChild(el('h2', 'home-hero-title', featuredTrack ? 'Pick up where the feeling left off.' : 'Make room for a new favorite.'));
  heroCopy.appendChild(el('p', 'home-hero-description', featuredTrack
    ? `${featuredTrack.title} · ${featuredTrack.artist || 'Unknown artist'}`
    : 'Search for a song or artist and start your collection.'));
  const heroButton = el('button', 'btn primary home-hero-button', featuredTrack ? 'Return to listening' : 'Find music');
  heroButton.type = 'button';
  heroButton.addEventListener('click', () => {
    if (state.nowPlaying) patch({ view: 'now-playing' });
    else if (featuredTrack) actions.playTrack(featuredTrack);
    else patch({ view: 'search' });
  });
  heroCopy.appendChild(heroButton);

  const heroArt = el('div', 'home-hero-art');
  const heroImage = document.createElement('img');
  heroImage.src = featuredTrack?.thumbnail || FALLBACK_ART;
  heroImage.alt = featuredTrack ? `Artwork for ${featuredTrack.title}` : '';
  heroImage.loading = 'lazy';
  heroArt.appendChild(heroImage);
  hero.append(heroCopy, heroArt);
  container.appendChild(hero);

  const tabBar = document.createElement('div');
  tabBar.className = 'home-tabs';
  [['for-you', 'For you'], ['quick-picks', 'Quick picks']].forEach(([key, label]) => {
    const tab = document.createElement('button');
    tab.className = 'home-tab' + (state.homeTab === key ? ' active' : '');
    tab.textContent = label;
    tab.setAttribute('aria-pressed', String(state.homeTab === key));
    tab.addEventListener('click', () => actions.setHomeTab(key));
    tabBar.appendChild(tab);
  });
  container.appendChild(tabBar);

  const favorites = state.favorites.map((id) => getTrack(id)).filter(Boolean);
  const quickPicks = state.homeRecommendations.slice(0, 8);
  const quickSection = document.createElement('section');
  quickSection.className = 'home-section';
  const quickHeading = document.createElement('div');
  quickHeading.className = 'home-section-heading';
  quickHeading.innerHTML = '<div><h2>Quick picks</h2><p>Learned from your listening over time.</p></div>';
  quickSection.appendChild(quickHeading);
  if (quickPicks.length) {
    const grid = document.createElement('div');
    grid.className = 'quick-picks-grid';
    quickPicks.forEach((track) => grid.appendChild(quickPickCard(track)));
    quickSection.appendChild(grid);
  } else {
    const empty = document.createElement('div');
    empty.className = 'home-empty-card';
    empty.innerHTML = `<strong>${state.homeRecommendationsLoading ? 'Learning your taste' : 'Your picks start here'}</strong><span>${state.homeRecommendationsLoading ? 'Finding songs from the artists you listen to most.' : 'Play a few songs and Quick Picks will learn your taste over time.'}</span>`;
    const search = document.createElement('button');
    search.className = 'btn'; search.textContent = 'Find music';
    search.addEventListener('click', () => patch({ view: 'search' }));
    empty.appendChild(search);
    quickSection.appendChild(empty);
  }
  container.appendChild(quickSection);
  if (!state.homeRecommendationsLoaded) actions.loadHomeRecommendations();
  if (state.homeTab === 'quick-picks') return;

  const topTracks = [...favorites, ...state.recents]
    .filter((track, index, all) => track?.id && all.findIndex((item) => item.id === track.id) === index)
    .slice(0, 10);
  const topSection = document.createElement('section');
  topSection.className = 'home-section';
  const topHeading = document.createElement('div');
  topHeading.className = 'home-section-heading';
  topHeading.innerHTML = '<div><h2>Top songs</h2><p>Your favorites and recently played tracks.</p></div>';
  topSection.appendChild(topHeading);
  topSection.appendChild(trackList(topTracks, { menu: true, emptyMessage: 'Play or favorite a few songs and your top songs will show up here.' }));
  container.appendChild(topSection);

  const recommendations = document.createElement('section');
  recommendations.className = 'home-section';
  const recHeading = document.createElement('div');
  recHeading.className = 'home-section-heading';
  recHeading.innerHTML = '<div><h2>Recommended for you</h2><p>Related tracks based on your listening.</p></div>';
  const refresh = document.createElement('button');
  refresh.className = 'btn'; refresh.textContent = 'Refresh';
  refresh.disabled = state.homeRecommendationsLoading || !state.binaries.ytdlp;
  refresh.addEventListener('click', () => actions.loadHomeRecommendations({ refresh: true }));
  recHeading.appendChild(refresh);
  recommendations.appendChild(recHeading);
  if (state.homeRecommendationsLoading) recommendations.appendChild(el('div', 'empty-state', 'Finding music based on your listening…'));
  else if (state.homeRecommendations.length) recommendations.appendChild(trackList(state.homeRecommendations, { menu: true }));
  else recommendations.appendChild(el('div', 'empty-state', state.binaries.ytdlp ? 'Play a few songs to get personalized recommendations.' : 'Set up yt-dlp in Settings to load music recommendations.'));
  container.appendChild(recommendations);
}

function renderSearchView(container) {
  container.appendChild(viewHeader('Search', 'Search streams directly via yt-dlp — nothing downloads until you tap the arrow.'));

  if (!state.binaries.ytdlp) {
    const banner = document.createElement('div');
    banner.className = 'banner warn';
    banner.style.display = 'flex';
    banner.style.alignItems = 'center';
    banner.style.justifyContent = 'space-between';
    banner.style.gap = '12px';
    const msg = document.createElement('span');
    msg.textContent = 'yt-dlp was not found — search and streaming are disabled.';
    const fixBtn = document.createElement('button');
    fixBtn.className = 'btn';
    fixBtn.textContent = 'Fix in Settings';
    fixBtn.addEventListener('click', () => patch({ view: 'settings' }));
    banner.append(msg, fixBtn);
    container.appendChild(banner);
  }

  const box = document.createElement('div');
  box.className = 'search-box';
  box.innerHTML = `<svg viewBox="0 0 20 20"><path d="M9 3a6 6 0 104.47 10.03l3.75 3.75 1.06-1.06-3.75-3.75A6 6 0 009 3zm-4.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0z"/></svg>
    <input type="text" id="search-input" placeholder="Search songs or artists" />`;
  container.appendChild(box);
  const input = box.querySelector('#search-input');
  input.value = state.searchQuery;
  input.addEventListener('input', (e) => actions.queueSearch(e.target.value));
  setTimeout(() => input.focus(), 0);

  if (state.searchError) {
    const banner = document.createElement('div');
    banner.className = 'banner error';
    banner.textContent = state.searchError;
    container.appendChild(banner);
  } else if (state.searchLoading) {
    container.appendChild(el('div', 'empty-state', 'Searching…'));
  } else if (state.searchQuery && state.searchResults.length === 0) {
    container.appendChild(el('div', 'empty-state', `No results for "${state.searchQuery}".`));
  } else if (!state.searchQuery) {
    if (state.searchHistory.length) container.appendChild(renderSearchHistory());
    else container.appendChild(el('div', 'empty-state', 'Start typing to search. Double-click a result to play it, or use the row actions to favorite, queue, download, or add it to a playlist.'));
  } else {
    container.appendChild(trackList(state.searchResults, { menu: true }));
  }
}

function renderSearchHistory() {
  const section = el('section', 'search-history');
  const heading = el('div', 'search-history-heading');
  heading.append(el('h2', '', 'Recent searches'));
  const clear = el('button', 'search-history-clear', 'Clear');
  clear.type = 'button';
  clear.addEventListener('click', () => actions.clearSearchHistory());
  heading.appendChild(clear);
  section.appendChild(heading);
  const list = el('div', 'search-history-list');
  state.searchHistory.forEach((query) => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'search-history-item';
    item.innerHTML = '<span class="search-history-icon" aria-hidden="true">↺</span><span class="search-history-query"></span><span class="search-history-repeat">Search again</span>';
    item.querySelector('.search-history-query').textContent = query;
    item.addEventListener('click', () => {
      const input = $('#search-input');
      if (input) input.value = query;
      actions.queueSearch(query);
    });
    list.appendChild(item);
  });
  section.appendChild(list);
  return section;
}

function renderRadioView(container) {
  const track = state.nowPlaying;
  const hero = document.createElement('section');
  hero.className = 'radio-hero';
  const art = document.createElement('img');
  art.className = 'radio-art';
  art.src = track?.thumbnail || FALLBACK_ART;
  art.alt = '';
  const copy = document.createElement('div');
  copy.innerHTML = `<div class="radio-kicker">Personal Station</div><h1 class="radio-title"></h1><p class="radio-copy">A continuous mix built from the song you’re listening to. Vinylstack keeps adding related tracks as you approach the end of the queue.</p>`;
  copy.querySelector('.radio-title').textContent = track ? `Station from ${track.title}` : 'Start a station';
  const button = document.createElement('button');
  button.className = 'btn primary';
  button.textContent = track ? 'Start station' : 'Play a song first';
  button.textContent = state.radio.active ? (state.radio.loading ? 'Building mix…' : 'Refresh mix') : (track ? 'Start station' : 'Play a song first');
  button.disabled = !track;
  button.onclick = () => actions.startRadio(track);
  copy.appendChild(button);
  if (state.radio.active) {
    const status = el('div', 'radio-copy', state.radio.loading ? 'Finding fresh recommendations…' : 'Station active · the queue grows as you listen');
    copy.appendChild(status);
    const stop = el('button', 'btn', 'Stop station');
    stop.onclick = () => actions.stopRadio();
    copy.appendChild(stop);
  }
  hero.append(art, copy);
  container.appendChild(hero);
  const queueTracks = state.queue.trackIds.map(id => getTrack(id)).filter(Boolean);
  if (queueTracks.length) {
    container.appendChild(viewHeader('Up next', 'Tracks currently queued by your station.'));
    container.appendChild(trackList(queueTracks, { menu: true }));
  }
}

function renderNowPlayingView(container) {
  const track = state.nowPlaying;
  const layout = el('div', 'now-playing-view');
  const current = el('section', 'now-playing-feature');
  const art = document.createElement('img');
  art.className = 'now-playing-feature-art';
  art.src = track?.thumbnail || FALLBACK_ART;
  art.alt = track ? `Cover art for ${track.title}` : 'Vinylstack artwork';
  const copy = el('div', 'now-playing-feature-copy');
  copy.append(el('div', 'radio-kicker', 'Now Playing'), el('h1', 'now-playing-feature-title', track?.title || 'Nothing playing'), el('p', 'now-playing-feature-artist', track?.artist || 'Choose a song to get started'));
  const progress = el('div', 'now-playing-feature-progress');
  const fill = document.createElement('span');
  fill.style.width = `${state.duration ? Math.min(100, state.currentTime / state.duration * 100) : 0}%`;
  progress.appendChild(fill);
  copy.appendChild(progress);
  const controls = el('div', 'now-playing-feature-controls');
  const prev = iconButton('◀', () => actions.skipPrev()); prev.title = 'Previous';
  const play = iconButton(state.isPlaying ? 'Ⅱ' : '▶', () => actions.togglePlayPause()); play.title = state.isPlaying ? 'Pause' : 'Play'; play.classList.add('feature-play');
  const next = iconButton('▶', () => actions.skipNext()); next.title = 'Next';
  controls.append(prev, play, next);
  copy.appendChild(controls);
  current.append(art, copy);
  const upcoming = el('section', 'up-next-section');
  const queue = state.queue.trackIds || [];
  const start = Math.max(0, state.queue.currentIndex + 1);
  const heading = el('div', 'up-next-heading');
  const headingCopy = el('div', 'up-next-heading-copy');
  headingCopy.append(el('div', 'radio-kicker', 'Queue'), el('h2', '', 'Up Next'));
  heading.append(headingCopy, el('span', 'up-next-count', `${Math.max(0, queue.length - start)} songs`));
  upcoming.appendChild(heading);
  const list = el('div', 'up-next-list');
  queue.forEach((id, index) => {
    const queued = getTrack(id);
    if (!queued || index < start) return;
    const row = el('button', 'up-next-row'); row.type = 'button';
    const thumb = document.createElement('img'); thumb.src = queued.thumbnail || FALLBACK_ART; thumb.alt = '';
    const meta = el('span', 'up-next-meta');
    meta.append(el('span', 'up-next-title', queued.title), el('span', 'up-next-artist', queued.artist || ''));
    row.append(thumb, meta);
    row.addEventListener('click', () => actions.playQueueIndex(index));
    list.appendChild(row);
  });
  if (!list.childElementCount) list.appendChild(el('div', 'up-next-empty', state.radio.active ? 'Finding more songs for your station…' : 'Your queue is empty. Add a song or start Radio to keep listening.'));
  upcoming.appendChild(list);
  layout.append(current, upcoming);
  container.appendChild(layout);
}

function renderDownloadsView(container) {
  container.appendChild(viewHeader('Downloads', 'Tracks saved to disk for offline playback.'));
  container.appendChild(trackList(state.library, { menu: true, downloadsView: true, emptyMessage: 'No downloads yet — download a track from Search to see it here.' }));
}

function renderFavoritesView(container) {
  container.appendChild(viewHeader('Favorites', 'Everything you\u2019ve hearted, across search, playlists, and downloads.'));
  const tracks = state.favorites.map((id) => getTrack(id)).filter(Boolean);
  container.appendChild(trackList(tracks, { menu: true, emptyMessage: 'Nothing favorited yet.' }));
}

function renderPlaylistsView(container) {
  container.appendChild(viewHeader('Playlists', 'Group tracks from search, favorites, and downloads into one list.'));

  const importCard = el('section', 'playlist-import-card');
  importCard.appendChild(el('h2', '', 'Import from YouTube Music'));
  importCard.appendChild(el('p', 'settings-desc', 'Paste a public playlist link. Up to 500 tracks will be added to your Vinylstack playlists.'));
  const importRow = el('div', 'playlist-import-row');
  const urlInput = document.createElement('input'); urlInput.type = 'url'; urlInput.placeholder = 'https://music.youtube.com/playlist?list=…'; urlInput.setAttribute('aria-label', 'YouTube Music playlist URL');
  const importButton = el('button', 'btn primary', 'Import playlist');
  const importStatus = el('div', 'playlist-import-status');
  const runImport = async () => {
    if (!urlInput.value.trim()) { importStatus.textContent = 'Paste a YouTube Music playlist link first.'; return; }
    importButton.disabled = true; importStatus.textContent = 'Reading playlist…';
    try {
      await actions.importYoutubeMusicPlaylist(urlInput.value.trim());
      importStatus.textContent = 'Playlist imported successfully.';
      urlInput.value = '';
    } catch (error) { importStatus.textContent = error.message || 'Could not import that playlist.'; }
    finally { importButton.disabled = false; }
  };
  importButton.addEventListener('click', runImport);
  urlInput.addEventListener('keydown', (event) => { if (event.key === 'Enter') runImport(); });
  importRow.append(urlInput, importButton);
  importCard.append(importRow, importStatus);
  container.appendChild(importCard);

  const row = document.createElement('div');
  row.className = 'new-playlist-row';
  row.innerHTML = `<input type="text" placeholder="New playlist name" id="new-playlist-name" /><button class="btn primary">Create</button>`;
  row.querySelector('button').addEventListener('click', () => {
    const input = row.querySelector('input');
    if (!input.value.trim()) return;
    actions.createPlaylist(input.value);
    input.value = '';
  });
  row.querySelector('input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') row.querySelector('button').click();
  });
  container.appendChild(row);

  if (!state.playlists.length) {
    container.appendChild(el('div', 'empty-state', 'No playlists yet — create one above.'));
    return;
  }

  const grid = document.createElement('div');
  grid.className = 'card-grid';
  state.playlists.forEach((p) => {
    const card = document.createElement('div');
    card.className = 'playlist-card';
    card.innerHTML = `<div class="playlist-card-name"></div><div class="playlist-card-count"></div>`;
    card.querySelector('.playlist-card-name').textContent = p.name;
    card.querySelector('.playlist-card-count').textContent = `${p.trackIds.length} track${p.trackIds.length === 1 ? '' : 's'}`;
    card.addEventListener('click', () => patch({ view: 'playlist-detail', activePlaylistId: p.id }));
    grid.appendChild(card);
  });
  container.appendChild(grid);
}

function renderPlaylistDetailView(container) {
  const playlist = state.playlists.find((p) => p.id === state.activePlaylistId);
  if (!playlist) { patch({ view: 'playlists' }); return; }

  const back = document.createElement('button');
  back.className = 'back-link';
  back.textContent = '← All playlists';
  back.addEventListener('click', () => patch({ view: 'playlists', activePlaylistId: null }));
  container.appendChild(back);

  const header = viewHeader(playlist.name, `${playlist.trackIds.length} track${playlist.trackIds.length === 1 ? '' : 's'}`);
  const actionsRow = document.createElement('div');
  actionsRow.style.display = 'flex';
  actionsRow.style.gap = '8px';
  actionsRow.style.marginBottom = '16px';

  const playAllBtn = document.createElement('button');
  playAllBtn.className = 'btn primary';
  playAllBtn.textContent = 'Play all';
  playAllBtn.disabled = !playlist.trackIds.length;
  playAllBtn.addEventListener('click', () => actions.playPlaylist(playlist.id));

  const shuffleBtn = document.createElement('button');
  shuffleBtn.className = 'btn';
  shuffleBtn.textContent = 'Shuffle';
  shuffleBtn.disabled = !playlist.trackIds.length;
  shuffleBtn.addEventListener('click', () => actions.playPlaylist(playlist.id, { shuffle: true }));

  const renameBtn = document.createElement('button');
  renameBtn.className = 'btn';
  renameBtn.textContent = 'Rename';
  renameBtn.addEventListener('click', () => {
    const name = prompt('Rename playlist', playlist.name);
    if (name && name.trim()) actions.renamePlaylist(playlist.id, name.trim());
  });

  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'btn danger';
  deleteBtn.textContent = 'Delete';
  deleteBtn.addEventListener('click', () => {
    if (confirm(`Delete "${playlist.name}"? This won\u2019t delete any downloads.`)) actions.deletePlaylist(playlist.id);
  });

  actionsRow.append(playAllBtn, shuffleBtn, renameBtn, deleteBtn);
  container.append(header, actionsRow);

  const tracks = playlist.trackIds.map((id) => getTrack(id)).filter(Boolean);
  container.appendChild(trackList(tracks, { menu: true, playlistId: playlist.id, emptyMessage: 'This playlist is empty — add tracks from Search, Favorites, or Downloads.' }));
}

function renderListenTogetherView(container) {
  const lt = state.listenTogether;
  container.appendChild(viewHeader('Listen Together', 'Share playback with friends in a synchronized room.'));

  const card = document.createElement('div');
  card.className = 'listen-card';
  card.innerHTML = `
    <div class="listen-status"><span class="listen-dot"></span><span class="listen-status-text"></span></div>
    <label class="listen-label">Your name</label>
    <input id="listen-name" class="listen-input" type="text" maxlength=30 placeholder="Your name" value="">
    <div class="listen-actions">
      <button id="listen-create" class="btn primary">Create room</button>
      <input id="listen-code" class="listen-input listen-code" maxlength=8 placeholder="Room code">
      <button id="listen-join" class="btn">Join room</button>
    </div>
    <div class="listen-server-row"><input id="listen-server" class="listen-input" placeholder="wss://metroserverx.meowery.eu/ws"><button id="listen-server-save" class="btn">Use server</button></div>
    <div class="listen-tools"><button id="listen-reconnect" class="btn">Reconnect</button><button id="listen-resync" class="btn">Resync playback</button></div>
    <div class="listen-hint">Default server: metroserverx.meowery.eu. You can change this to another ws:// or wss:// server. Vinylstack’s optional local server runs on port 8787.</div>
    <div class="listen-error" role="status"></div>
    <div class="listen-room"></div>
  `;
  const name = card.querySelector('#listen-name');
  name.value = localStorage.getItem('vinylstack.listenName') || '';
  const serverInput = card.querySelector('#listen-server');
  serverInput.value = actions.listenTogether.getServerUrl();
  card.querySelector('#listen-create').addEventListener('click', () => {
    actions.listenTogether.createRoom(name.value.trim() || 'Vinylstack user');
  });
  card.querySelector('#listen-join').addEventListener('click', () => {
    actions.listenTogether.joinRoom(card.querySelector('#listen-code').value, name.value.trim() || 'Vinylstack user');
  });
  card.querySelector('#listen-server-save').addEventListener('click', () => {
    actions.listenTogether.configure(card.querySelector('#listen-server').value);
  });
  card.querySelector('#listen-reconnect').addEventListener('click', () => actions.listenTogether.reconnect());
  card.querySelector('#listen-resync').addEventListener('click', () => actions.listenTogether.requestSync());
  name.addEventListener('input', () => localStorage.setItem('vinylstack.listenName', name.value));

  const statusText = card.querySelector('.listen-status-text');
  const statusMap = { idle: 'Not connected', connecting: 'Connecting…', connected: 'Connected to server', host: 'You are the host', guest: 'Connected as guest', disconnected: 'Disconnected' };
  statusText.textContent = statusMap[lt.status] || lt.status;
  const errorText = card.querySelector('.listen-error');
  errorText.textContent = lt.error || '';
  errorText.hidden = !lt.error;
  card.querySelector('#listen-resync').disabled = !lt.roomCode;

  const room = card.querySelector('.listen-room');
  if (lt.roomCode) {
    room.innerHTML = `<div class="room-code">${lt.roomCode}</div><div class="listen-hint">Share this code. Playback changes from the host will sync automatically.</div>`;
    const copy = document.createElement('button');
    copy.className = 'btn'; copy.textContent = 'Copy code';
    copy.onclick = () => navigator.clipboard?.writeText(lt.roomCode);
    room.appendChild(copy);
  }
  if (lt.status === 'host' || lt.status === 'guest') {
    const leave = document.createElement('button'); leave.className = 'btn danger'; leave.textContent = 'Leave room'; leave.onclick = () => actions.listenTogether.leaveRoom(); room.appendChild(leave);
  }
  if (lt.status === 'host' && (lt.users || []).length) {
    const users = document.createElement('div'); users.className = 'listen-users';
    users.innerHTML = '<h3>People in the room</h3>';
    lt.users.forEach(u => {
      const row = document.createElement('div'); row.className = 'listen-user';
      row.innerHTML = `<span>${u.username || 'Guest'}</span>`;
      if (u.pending) { const b=document.createElement('button'); b.className='btn'; b.textContent='Approve'; b.onclick=()=>actions.listenTogether.approveUser(u.id); row.appendChild(b); }
      users.appendChild(row);
    });
    room.appendChild(users);
  }
  container.appendChild(card);
}

let settingsCategory = 'general';
function renderSettingsView(container) {
  container.appendChild(viewHeader('Settings', 'Search, playback, appearance, and where downloads are saved.'));
  const categories = [['general', 'General'], ['playback', 'Playback'], ['visualizer', 'Visualizer'], ['downloads', 'Downloads'], ['dependencies', 'Dependencies'], ['updates', 'Updates'], ['credits', 'Credits']];
  const settingsLayout = document.createElement('div');
  settingsLayout.className = 'settings-layout';
  const settingsNav = document.createElement('nav');
  settingsNav.className = 'settings-nav';
  settingsNav.setAttribute('aria-label', 'Settings categories');
  const settingsContent = document.createElement('div');
  settingsContent.className = 'settings-content';
  categories.forEach(([key, label]) => {
    const button = document.createElement('button');
    button.className = 'settings-nav-item' + (settingsCategory === key ? ' active' : '');
    button.textContent = label;
    button.setAttribute('aria-pressed', String(settingsCategory === key));
    button.addEventListener('click', () => {
      settingsCategory = key;
      settingsNav.querySelectorAll('.settings-nav-item').forEach((item) => {
        const active = item.dataset.category === key;
        item.classList.toggle('active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      settingsContent.dataset.active = key;
    });
    button.dataset.category = key;
    settingsNav.appendChild(button);
  });
  settingsContent.dataset.active = settingsCategory;
  settingsLayout.append(settingsNav, settingsContent);
  container.appendChild(settingsLayout);

  const searchSettings = document.createElement('div');
  searchSettings.className = 'settings-section';
  searchSettings.dataset.category = 'general';
  searchSettings.innerHTML = '<h3>Search</h3>';
  const videosRow = settingsRow('Exclude video-style results', 'Hide music videos, lyric videos, live performances, and visualizers from search and Radio.', null);
  const videosToggle = document.createElement('input');
  videosToggle.type = 'checkbox';
  videosToggle.className = 'settings-toggle';
  videosToggle.checked = state.excludeVideos;
  videosToggle.setAttribute('aria-label', 'Exclude video-style search results');
  videosToggle.addEventListener('change', () => actions.setExcludeVideos(videosToggle.checked));
  videosRow.appendChild(videosToggle);
  searchSettings.appendChild(videosRow);
  settingsContent.appendChild(searchSettings);

  // binaries status
  const status = document.createElement('div');
  status.className = 'settings-section';
  status.dataset.category = 'dependencies';
  status.innerHTML = `<h3>Dependencies</h3>`;

  const ytdlpRow = settingsRow(
    'yt-dlp',
    state.binaries.ytdlp ? `Found — ${state.binaries.ytdlpVersion || 'working'}` : (state.binaries.ytdlpError || 'Not found on your PATH'),
    null
  );
  const ytdlpLocate = document.createElement('button');
  ytdlpLocate.className = 'btn';
  ytdlpLocate.textContent = 'Locate manually…';
  ytdlpLocate.addEventListener('click', () => actions.locateBinary('ytdlp'));
  ytdlpRow.appendChild(ytdlpLocate);
  status.appendChild(ytdlpRow);

  const ffmpegRow = settingsRow(
    'ffmpeg',
    state.binaries.ffmpeg ? `Found — ${state.binaries.ffmpegVersion || 'working'}` : (state.binaries.ffmpegError || 'Not found on your PATH'),
    null
  );
  const ffmpegLocate = document.createElement('button');
  ffmpegLocate.className = 'btn';
  ffmpegLocate.textContent = 'Locate manually…';
  ffmpegLocate.addEventListener('click', () => actions.locateBinary('ffmpeg'));
  ffmpegRow.appendChild(ffmpegLocate);
  status.appendChild(ffmpegRow);

  const recheckRow = document.createElement('div');
  recheckRow.style.marginTop = '10px';
  const recheckBtn = document.createElement('button');
  recheckBtn.className = 'btn primary';
  recheckBtn.textContent = 'Re-check';
  recheckBtn.addEventListener('click', () => actions.recheckBinaries());
  recheckRow.appendChild(recheckBtn);
  status.appendChild(recheckRow);

  if (!state.binaries.ytdlp) {
    const hint = document.createElement('div');
    hint.className = 'settings-desc';
    hint.style.marginTop = '10px';
    hint.textContent = 'If yt-dlp is installed but still not found, use "Locate manually" and pick the yt-dlp(.exe) file directly — this is the most reliable fix and skips PATH entirely.';
    status.appendChild(hint);
  }
  settingsContent.appendChild(status);

  // appearance
  const appearance = document.createElement('div');
  appearance.className = 'settings-section';
  appearance.dataset.category = 'general';
  appearance.innerHTML = `<h3>Appearance</h3>`;

  const themeRow = document.createElement('div');
  themeRow.className = 'settings-row';
  themeRow.innerHTML = `<div><div class="settings-label">Theme</div></div>`;
  const seg = document.createElement('div');
  seg.className = 'segmented';
  ['dark', 'light'].forEach((t) => {
    const b = document.createElement('button');
    b.textContent = t === 'dark' ? 'Dark' : 'Light';
    b.className = state.theme === t ? 'active' : '';
    b.addEventListener('click', () => actions.setTheme(t));
    seg.appendChild(b);
  });
  themeRow.appendChild(seg);
  appearance.appendChild(themeRow);

  const accentRow = document.createElement('div');
  accentRow.className = 'settings-row';
  accentRow.innerHTML = `<div><div class="settings-label">Accent color</div></div>`;
  const swatches = document.createElement('div');
  swatches.className = 'swatches';
  ['#c97b3d', '#6fa88f', '#7c93c9', '#c97ba3', '#c9a63d'].forEach((color) => {
    const sw = document.createElement('div');
    sw.className = 'swatch' + (state.accent === color ? ' active' : '');
    sw.style.background = color;
    sw.addEventListener('click', () => actions.setAccent(color));
    swatches.appendChild(sw);
  });
  accentRow.appendChild(swatches);
  appearance.appendChild(accentRow);
  const effectsRow = settingsRow('Soft blur and gradients', 'Use subtle glass blur, gradients, and depth in the interface.', null);
  const effectsToggle = document.createElement('input');
  effectsToggle.type = 'checkbox';
  effectsToggle.className = 'settings-toggle';
  effectsToggle.checked = state.visualEffects !== false;
  effectsToggle.setAttribute('aria-label', 'Enable soft blur and gradients');
  effectsToggle.addEventListener('change', () => actions.setVisualEffects(effectsToggle.checked));
  effectsRow.appendChild(effectsToggle);
  appearance.appendChild(effectsRow);
  settingsContent.appendChild(appearance);

  // downloads
  const dl = document.createElement('div');
  dl.className = 'settings-section';
  dl.dataset.category = 'downloads';
  dl.innerHTML = `<h3>Downloads</h3>`;
  const dirRow = settingsRow('Save location', 'Where downloaded audio files are stored', null);
  const chooseBtn = document.createElement('button');
  chooseBtn.className = 'btn';
  chooseBtn.textContent = 'Choose folder…';
  chooseBtn.addEventListener('click', () => actions.chooseDownloadDir());
  dirRow.appendChild(chooseBtn);
  dl.appendChild(dirRow);
  settingsContent.appendChild(dl);

  // playback
  const pb = document.createElement('div');
  pb.className = 'settings-section';
  pb.dataset.category = 'playback';
  pb.innerHTML = `<h3>Playback</h3>`;
  const audioQualityRow = settingsRow(
    'Audio quality',
    'Preferred yt-dlp stream quality. The new setting is used when a stream is loaded.',
    null
  );
  const audioQualityOptions = document.createElement('div');
  audioQualityOptions.className = 'segmented';
  [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']].forEach(([quality, label]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = label;
    button.className = state.audioQuality === quality ? 'active' : '';
    button.setAttribute('aria-pressed', String(state.audioQuality === quality));
    button.addEventListener('click', () => {
      audioQualityOptions.querySelectorAll('button').forEach((option) => {
        const selected = option === button;
        option.classList.toggle('active', selected);
        option.setAttribute('aria-pressed', String(selected));
      });
      actions.setAudioQuality(quality);
    });
    audioQualityOptions.appendChild(button);
  });
  audioQualityRow.appendChild(audioQualityOptions);
  pb.appendChild(audioQualityRow);
  const sleepRow = document.createElement('div');
  sleepRow.className = 'settings-row';
  sleepRow.innerHTML = `<div><div class="settings-label">Sleep timer</div><div class="settings-desc">Pause playback automatically</div></div>`;
  const sleepSeg = document.createElement('div');
  sleepSeg.className = 'segmented';
  [['Off', null], ['15m', 15], ['30m', 30], ['60m', 60]].forEach(([label, minutes]) => {
    const b = document.createElement('button');
    b.textContent = label;
    b.className = state.sleepTimerMinutes === minutes ? 'active' : '';
    b.addEventListener('click', () => actions.setSleepTimer(minutes));
    sleepSeg.appendChild(b);
  });
  sleepRow.appendChild(sleepSeg);
  pb.appendChild(sleepRow);
  settingsContent.appendChild(pb);

  const visualizerSettings = document.createElement('div');
  visualizerSettings.className = 'settings-section';
  visualizerSettings.dataset.category = 'visualizer';
  visualizerSettings.innerHTML = '<h3>Visualizer</h3>';
  const bandsRow = settingsRow(
    'Frequency bands',
    'Choose 60, 120, or 204 logarithmically spaced bands across the spectrum.',
    null
  );
  const bandOptions = document.createElement('div');
  bandOptions.className = 'segmented visualizer-quality-options';
  [[60, '60'], [120, '120'], [204, '204']].forEach(([bands, label]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = label;
    button.className = state.visualizerBands === bands ? 'active' : '';
    button.setAttribute('aria-pressed', String(state.visualizerBands === bands));
    button.addEventListener('click', () => {
      bandOptions.querySelectorAll('button').forEach((option) => {
        const active = option === button;
        option.classList.toggle('active', active);
        option.setAttribute('aria-pressed', String(active));
      });
      actions.setVisualizerBands(bands);
    });
    bandOptions.appendChild(button);
  });
  bandsRow.appendChild(bandOptions);
  visualizerSettings.appendChild(bandsRow);

  const responsivenessRow = settingsRow(
    'Band responsiveness',
    'Higher values make the bands react faster. Changes preview immediately.',
    null
  );
  const responsivenessControl = document.createElement('div');
  responsivenessControl.className = 'visualizer-response-control';
  const responsivenessSlider = document.createElement('input');
  responsivenessSlider.type = 'range';
  responsivenessSlider.min = '0';
  responsivenessSlider.max = '100';
  responsivenessSlider.step = '1';
  responsivenessSlider.value = String(state.visualizerResponsiveness);
  responsivenessSlider.setAttribute('aria-label', 'Visualizer band responsiveness');
  responsivenessSlider.setAttribute('aria-valuetext', `${state.visualizerResponsiveness}%`);
  const responsivenessValue = document.createElement('output');
  responsivenessValue.className = 'visualizer-response-value';
  responsivenessValue.textContent = `${state.visualizerResponsiveness}%`;
  responsivenessSlider.addEventListener('input', () => {
    const value = Number(responsivenessSlider.value);
    responsivenessValue.textContent = `${value}%`;
    responsivenessSlider.setAttribute('aria-valuetext', `${value}%`);
    actions.previewVisualizerResponsiveness(value);
  });
  responsivenessSlider.addEventListener('change', () => actions.setVisualizerResponsiveness(Number(responsivenessSlider.value)));
  responsivenessControl.append(responsivenessSlider, responsivenessValue);
  responsivenessRow.appendChild(responsivenessControl);
  visualizerSettings.appendChild(responsivenessRow);

  const visualizerColorRow = settingsRow(
    'Visualizer color',
    'Choose the spectrum band color independently from the app accent.',
    null
  );
  const visualizerColorControl = document.createElement('div');
  visualizerColorControl.className = 'visualizer-color-control';
  const visualizerColor = document.createElement('input');
  visualizerColor.type = 'color';
  visualizerColor.value = state.visualizerColor;
  visualizerColor.setAttribute('aria-label', 'Visualizer band color');
  const visualizerColorValue = document.createElement('output');
  visualizerColorValue.className = 'visualizer-color-value';
  visualizerColorValue.textContent = state.visualizerColor.toUpperCase();
  visualizerColor.addEventListener('input', () => {
    visualizerColorValue.textContent = visualizerColor.value.toUpperCase();
  });
  visualizerColor.addEventListener('change', () => actions.setVisualizerColor(visualizerColor.value));
  visualizerColorControl.append(visualizerColor, visualizerColorValue);
  visualizerColorRow.appendChild(visualizerColorControl);
  visualizerSettings.appendChild(visualizerColorRow);
  settingsContent.appendChild(visualizerSettings);

  const updates = document.createElement('div');
  updates.className = 'settings-section';
  updates.dataset.category = 'updates';
  updates.innerHTML = '<h3>Updates</h3>';
  const updateCard = document.createElement('div');
  updateCard.className = 'update-card';
  const updateHeading = document.createElement('div');
  updateHeading.className = 'update-card-heading';
  updateHeading.innerHTML = '<div><span class="update-eyebrow">VINYLSTACK</span><h4>Stay in the groove</h4></div><span class="update-version"></span>';
  updateHeading.querySelector('.update-version').textContent = `Version ${state.updateStatus?.currentVersion || '—'}`;
  const updateMessage = document.createElement('p');
  updateMessage.className = 'update-message';
  const updateState = state.updateStatus || { status: 'idle' };
  const statusMessages = {
    idle: 'Check GitHub for the latest version.',
    checking: 'Looking for a newer version…',
    current: 'You’re up to date.',
    available: `Version ${updateState.version || 'new'} is ready to download.`,
    downloading: `Downloading version ${updateState.version || 'update'}…`,
    downloaded: `Version ${updateState.version || 'update'} is ready to install.`,
    error: updateState.error || 'The update check could not finish.'
  };
  updateMessage.textContent = updateState.status === 'error' ? (updateState.error || statusMessages.error) : statusMessages[updateState.status] || statusMessages.idle;
  updateMessage.dataset.kind = updateState.status === 'error' ? 'error' : 'normal';
  const progress = document.createElement('div');
  progress.className = 'update-progress' + (updateState.status === 'downloading' ? ' visible' : '');
  progress.setAttribute('role', 'progressbar');
  progress.setAttribute('aria-valuemin', '0');
  progress.setAttribute('aria-valuemax', '100');
  progress.setAttribute('aria-valuenow', String(updateState.percent || 0));
  const progressFill = document.createElement('span');
  progressFill.style.width = `${Math.max(0, Math.min(100, updateState.percent || 0))}%`;
  progress.appendChild(progressFill);
  const progressLabel = document.createElement('span');
  progressLabel.className = 'update-progress-label';
  progressLabel.textContent = updateState.status === 'downloading' ? `${updateState.percent || 0}%` : '';
  const updateActions = document.createElement('div');
  updateActions.className = 'update-actions';
  const checkUpdates = document.createElement('button');
  checkUpdates.className = 'btn primary';
  checkUpdates.textContent = updateState.status === 'checking' ? 'Checking…' : 'Check for updates';
  checkUpdates.disabled = ['checking', 'downloading'].includes(updateState.status);
  checkUpdates.addEventListener('click', () => window.vinylstack.updates.check());
  updateActions.appendChild(checkUpdates);
  if (updateState.status === 'available') {
    const downloadUpdate = document.createElement('button');
    downloadUpdate.className = 'btn';
    downloadUpdate.textContent = 'Download update';
    downloadUpdate.addEventListener('click', () => window.vinylstack.updates.download());
    updateActions.appendChild(downloadUpdate);
  }
  if (updateState.status === 'downloaded') {
    const installUpdate = document.createElement('button');
    installUpdate.className = 'btn primary';
    installUpdate.textContent = 'Install and restart';
    installUpdate.addEventListener('click', () => window.vinylstack.updates.install());
    updateActions.appendChild(installUpdate);
  }
  updateCard.append(updateHeading, updateMessage, progress, progressLabel, updateActions);
  updates.appendChild(updateCard);
  const autoRow = settingsRow('Automatic updates', 'Off by default. When enabled, Vinylstack downloads new versions and asks before restarting.', null);
  const autoToggle = document.createElement('input');
  autoToggle.type = 'checkbox';
  autoToggle.className = 'settings-toggle';
  autoToggle.checked = !!state.autoUpdate;
  autoToggle.setAttribute('aria-label', 'Enable automatic updates');
  autoToggle.addEventListener('change', async () => {
    const enabled = await window.vinylstack.updates.setAuto(autoToggle.checked);
    patch({ autoUpdate: enabled });
  });
  autoRow.appendChild(autoToggle);
  updates.appendChild(autoRow);
  settingsContent.appendChild(updates);

  const credits = document.createElement('div');
  credits.className = 'settings-section';
  credits.dataset.category = 'credits';
  credits.innerHTML = '<h3>Credits</h3>';
  credits.appendChild(settingsRow('Creator', 'Gicu123', null));
  settingsContent.appendChild(credits);
}

function settingsRow(label, desc, control) {
  const row = document.createElement('div');
  row.className = 'settings-row';
  row.innerHTML = `<div><div class="settings-label"></div><div class="settings-desc"></div></div>`;
  row.querySelector('.settings-label').textContent = label;
  row.querySelector('.settings-desc').textContent = desc || '';
  if (control) row.appendChild(control);
  return row;
}

function el(tag, className, text) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (text) e.textContent = text;
  return e;
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------

const VIEW_RENDERERS = {
  home: renderHomeView,
  search: renderSearchView,
  radio: renderRadioView,
  downloads: renderDownloadsView,
  favorites: renderFavoritesView,
  playlists: renderPlaylistsView,
  'playlist-detail': renderPlaylistDetailView,
  settings: renderSettingsView,
  'now-playing': renderNowPlayingView,
  'listen-together': renderListenTogetherView
};

const MAIN_VIEW_KEYS = new Set([
  'view','activePlaylistId','searchQuery','searchResults','searchLoading','searchError','searchHistory',
  'homeTab','homeRecommendations','homeRecommendationsLoading','homeRecommendationsLoaded',
  'library','playlists','favorites','recents','queue','radio','nowPlaying','binaries',
  'excludeVideos','theme','accent','sleepTimerMinutes','listenTogether'
]);
const SIDE_PANEL_KEYS = new Set(['sidePanelOpen','sidePanelTab','queue','lyrics','lyricsLoading','equalizer','nowPlaying']);
const FULLSCREEN_KEYS = new Set(['fullscreenPlayer','nowPlaying','lyrics','lyricsLoading']);

export function renderApp(changed = null) {
  const keys = changed ? Object.keys(changed) : null;
  if (!keys || keys.includes('view')) renderNav();
  const listenViewNeedsRefresh = state.view === 'listen-together'
    ? (!keys || keys.includes('view') || keys.includes('listenTogether'))
    : (!keys || keys.some((key) => MAIN_VIEW_KEYS.has(key)));
  if (listenViewNeedsRefresh) renderMainView();
  $('#np-up-next').classList.toggle('on', state.view === 'now-playing');
  renderNowPlaying();
  if (!keys || keys.some((key) => SIDE_PANEL_KEYS.has(key))) renderSidePanel();
  if (!keys || keys.includes('toast')) renderToast();
  if (!keys || keys.some((key) => FULLSCREEN_KEYS.has(key))) renderFullscreenPlayer();
}

function renderNav() {
  $$('.nav-item').forEach((btn) => {
    const v = btn.dataset.view;
    btn.title = btn.textContent.trim();
    const active = v === state.view || (v === 'playlists' && state.view === 'playlist-detail');
    btn.classList.toggle('active', active);
  });
}

function renderMainView() {
  const container = $('#view-content');
  container.innerHTML = '';
  if (container.dataset.view !== state.view) {
    container.dataset.view = state.view;
    container.classList.remove('view-enter');
    void container.offsetWidth;
    container.classList.add('view-enter');
  }
  const renderer = VIEW_RENDERERS[state.view] || renderSearchView;
  renderer(container);
}

// ---------------------------------------------------------------------------
// Now playing bar
// ---------------------------------------------------------------------------

function renderNowPlaying() {
  const track = state.nowPlaying;
  $('#now-playing-bar').classList.toggle('is-playing', state.isPlaying);
  $('#now-playing-bar').classList.toggle('loading', state.playbackLoading);
  $('#now-playing-bar').setAttribute('aria-busy', String(state.playbackLoading));
  $('#np-art').src = track?.thumbnail || FALLBACK_ART;
  $('#np-art-ring').style.setProperty('--play-progress', `${state.duration ? Math.min(100, state.currentTime / state.duration * 100) : 0}%`);
  $('#np-title').textContent = track ? track.title : 'Nothing playing';
  $('#np-artist').textContent = track ? track.artist : 'Search for something to start';
  if ('mediaSession' in navigator && track) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.title || 'Vinylstack', artist: track.artist || '', album: track.album || '',
        artwork: track.thumbnail ? [{ src: track.thumbnail }] : []
      });
      navigator.mediaSession.playbackState = state.isPlaying ? 'playing' : 'paused';
    } catch (_) { /* Media metadata support varies by Electron platform. */ }
  }

  const favBtn = $('#np-favorite');
  favBtn.disabled = !track;
  favBtn.classList.toggle('on', !!track && actions.isFavorite(track.id));
  favBtn.onclick = () => track && actions.toggleFavorite(track);

  $('#icon-play').classList.toggle('hidden', state.isPlaying);
  $('#icon-pause').classList.toggle('hidden', !state.isPlaying);
  const featurePlay = $('.now-playing-feature-controls .feature-play');
  if (featurePlay) { featurePlay.textContent = state.isPlaying ? 'Ⅱ' : '▶'; featurePlay.disabled = state.playbackLoading; }

  $('#np-shuffle').classList.toggle('on', state.queue.shuffle);
  const repeatBtn = $('#np-repeat');
  repeatBtn.classList.toggle('on', state.queue.repeat !== 'off');
  repeatBtn.title = state.queue.repeat === 'one' ? 'Repeat one' : state.queue.repeat === 'all' ? 'Repeat all' : 'Repeat';

  $('#np-current-time').textContent = formatTime(state.currentTime);
  $('#np-duration').textContent = formatTime(state.duration);
  const seekbar = $('#np-seekbar');
  if (document.activeElement !== seekbar) {
    seekbar.max = state.duration || 0;
    seekbar.value = state.currentTime || 0;
  }

  $('#np-lyrics-toggle').classList.toggle('on', state.sidePanelTab === 'lyrics' && state.sidePanelOpen);
  $('#np-eq-toggle').classList.toggle('on', state.sidePanelTab === 'equalizer' && state.sidePanelOpen);

  $('#np-sleep-indicator').textContent = state.sleepTimerRemainingMs
    ? formatTime(state.sleepTimerRemainingMs / 1000) : '';
  $('#speed-reset').textContent = `${state.playbackRate.toFixed(2)}×`;
  $('#speed-down').disabled = state.playbackRate <= 0.5;
  $('#speed-up').disabled = state.playbackRate >= 2;
  $('#tape-reel').classList.toggle('spinning', state.isPlaying);
  $('#tape-reel').classList.toggle('varispeed', state.playbackRate !== 1);
}

function renderFullscreenPlayer() {
  const root = $('#fullscreen-player');
  root.classList.toggle('open', !!state.fullscreenPlayer);
  const lyricsAvailable = !!(state.lyrics?.synced || state.lyrics?.plain);
  root.classList.toggle('no-lyrics', !state.lyricsLoading && !lyricsAvailable);
  const track = state.nowPlaying;
  $('#fullscreen-art').src = track?.thumbnail || FALLBACK_ART;
  root.style.setProperty('--player-art', `url("${track?.thumbnail || FALLBACK_ART}")`);
  $('#fullscreen-title').textContent = track?.title || 'Nothing playing';
  $('#fullscreen-artist').textContent = track?.artist || '';
  $('#fullscreen-current').textContent = formatTime(state.currentTime);
  $('#fullscreen-duration').textContent = formatTime(state.duration);
  const seek = $('#fullscreen-seek');
  seek.max = state.duration || 0;
  if (document.activeElement !== seek) seek.value = state.currentTime || 0;
  seek.style.setProperty('--seek-progress', `${state.duration ? Math.min(100, state.currentTime / state.duration * 100) : 0}%`);
  const lyrics = $('#fullscreen-lyrics');
  lyrics.innerHTML = '';
  if (state.lyricsLoading) { lyrics.textContent = 'Looking up lyrics…'; return; }
  if (state.lyrics?.synced) {
    parseLrc(state.lyrics.synced).forEach(line => {
      const div = document.createElement('div');
      div.className = 'fullscreen-lyric-line' + (line.time <= state.currentTime ? ' past' : '');
      div.dataset.time = line.time; div.textContent = line.text || ' '; lyrics.appendChild(div);
    });
    updateTimedLyrics(lyrics, 'fullscreen-lyric-line');
  } else if (state.lyrics?.plain) lyrics.textContent = state.lyrics.plain;
  else lyrics.textContent = 'No lyrics found for this track.';
}

// ---------------------------------------------------------------------------
// Side panel
// ---------------------------------------------------------------------------

function renderSidePanel() {
  const panel = $('#side-panel');
  panel.classList.toggle('open', !!state.sidePanelOpen);
  $$('.side-panel-tabs button[data-tab]').forEach((b) => {
    b.classList.toggle('active', b.dataset.tab === state.sidePanelTab);
  });

  const content = $('#side-panel-content');
  content.innerHTML = '';
  if (state.sidePanelTab === 'queue') content.appendChild(renderQueuePanel());
  else if (state.sidePanelTab === 'lyrics') content.appendChild(renderLyricsPanel());
  else if (state.sidePanelTab === 'equalizer') content.appendChild(renderEqPanel());
}

function renderQueuePanel() {
  const wrap = document.createElement('div');
  const { trackIds, currentIndex } = state.queue;
  const heading = el('div', 'queue-panel-heading');
  heading.appendChild(el('strong', '', 'Up Next'));
  const clear = el('button', 'queue-clear-btn', 'Clear queue');
  clear.type = 'button';
  clear.disabled = trackIds.length === 0;
  clear.addEventListener('click', () => actions.clearQueue());
  heading.appendChild(clear);
  wrap.appendChild(heading);
  if (!trackIds.length) {
    wrap.innerHTML = `<div class="queue-empty">Queue is empty. Play something, or use the + button on any track to queue it next.</div>`;
    return wrap;
  }
  trackIds.forEach((id, i) => {
    const track = getTrack(id);
    if (!track) return;
    const row = document.createElement('div');
    row.className = 'queue-row' + (i === currentIndex ? ' current' : '');
    row.draggable = true;
    row.innerHTML = `
      <div class="drag-handle">⋮⋮</div>
      <img src="${track.thumbnail || FALLBACK_ART}" alt="" />
      <div class="track-info">
        <div class="track-title"></div>
        <div class="track-artist"></div>
      </div>
    `;
    row.querySelector('.track-title').textContent = track.title;
    row.querySelector('.track-artist').textContent = track.artist;
    row.querySelector('.track-info').addEventListener('click', () => actions.playQueueIndex(i));
    row.querySelector('.track-info').style.cursor = 'pointer';

    const removeBtn = iconButton('×', () => actions.removeFromQueue(i));
    row.appendChild(removeBtn);

    row.addEventListener('dragstart', (e) => e.dataTransfer.setData('text/plain', String(i)));
    row.addEventListener('dragover', (e) => e.preventDefault());
    row.addEventListener('drop', (e) => {
      e.preventDefault();
      const from = Number(e.dataTransfer.getData('text/plain'));
      actions.reorderQueue(from, i);
    });

    wrap.appendChild(row);
  });
  return wrap;
}

function renderLyricsPanel() {
  const wrap = document.createElement('div');
  if (!state.nowPlaying) {
    wrap.innerHTML = `<div class="lyrics-empty">Play a track to see its lyrics.</div>`;
    return wrap;
  }
  if (state.lyricsLoading) {
    wrap.innerHTML = `<div class="lyrics-empty">Looking up lyrics…</div>`;
    return wrap;
  }
  if (!state.lyrics || (!state.lyrics.synced && !state.lyrics.plain)) {
    wrap.innerHTML = `<div class="lyrics-empty">No lyrics found for this track.</div>`;
    return wrap;
  }
  const panel = document.createElement('div');
  wrap.className = 'lyrics-content';
  panel.className = 'lyrics-panel';
  if (state.lyrics.synced) {
    const lines = parseLrc(state.lyrics.synced);
    lines.forEach((line) => {
      const div = document.createElement('div');
      div.className = 'lyric-line';
      div.dataset.time = line.time;
      div.textContent = line.text || '\u00A0';
      panel.appendChild(div);
    });
  } else {
    panel.textContent = state.lyrics.plain;
  }
  wrap.appendChild(panel);
  return wrap;
}

function parseLrc(lrc) {
  return lrc.split('\n').map((line) => {
    const m = line.match(/\[(\d+):(\d+(?:\.\d+)?)\]\s*(.*)/);
    if (!m) return null;
    const time = Number(m[1]) * 60 + Number(m[2]);
    return { time, text: m[3] };
  }).filter(Boolean);
}

// highlight the active synced-lyric line as playback progresses
export function updateLyricHighlight() {
  if (state.sidePanelTab !== 'lyrics' || !state.sidePanelOpen) return;
  const panel = $('.lyrics-panel');
  if (panel) updateTimedLyrics(panel, 'lyric-line');
}

function updateTimedLyrics(container, className) {
  const lines = $$(`.${className}`, container);
  if (!lines.length) return;
  let activeIndex = -1;
  lines.forEach((line, i) => {
    const past = Number(line.dataset.time) <= state.currentTime;
    line.classList.toggle('past', past);
    if (past) activeIndex = i;
  });
  const activeLine = activeIndex >= 0 ? lines[activeIndex] : null;
  lines.forEach((line, i) => line.classList.toggle('active', i === activeIndex));
  if (activeLine && activeLine !== container._lastAutoScrolledLine) {
    const containerRect = container.getBoundingClientRect();
    const lineRect = activeLine.getBoundingClientRect();
    const targetTop = container.scrollTop + lineRect.top - containerRect.top - (container.clientHeight - activeLine.offsetHeight) / 2;
    container.scrollTo({ top: Math.max(0, targetTop), behavior: 'smooth' });
    container._lastAutoScrolledLine = activeLine;
  }
}

function renderEqPanel() {
  const wrap = document.createElement('div');
  wrap.className = 'eq-panel';

  const presets = document.createElement('div');
  presets.className = 'eq-presets';
  const PRESET_NAMES = { flat: 'Flat', bass: 'Bass boost', treble: 'Treble boost', vocal: 'Vocal', rock: 'Rock', pop: 'Pop', electronic: 'Electronic' };
  Object.entries(PRESET_NAMES).forEach(([key, label]) => {
    const b = document.createElement('button');
    b.className = 'eq-preset-btn' + (state.equalizer.preset === key ? ' active' : '');
    b.textContent = label;
    b.addEventListener('click', async () => {
      const mod = await import('./player.js');
      actions.setEqualizer({ preset: key, bands: [...mod.EQ_PRESETS[key]] });
    });
    presets.appendChild(b);
  });
  wrap.appendChild(presets);

  const bandsWrap = document.createElement('div');
  bandsWrap.className = 'eq-bands';
  import('./player.js').then((mod) => {
    mod.EQ_BANDS_HZ.forEach((hz, i) => {
      const col = document.createElement('div');
      col.className = 'eq-band';
      const slider = document.createElement('input');
      slider.type = 'range';
      slider.min = -12;
      slider.max = 12;
      slider.step = 1;
      slider.value = state.equalizer.bands[i] ?? 0;
      slider.addEventListener('input', (e) => {
        const bands = [...state.equalizer.bands];
        bands[i] = Number(e.target.value);
        actions.setEqualizer({ preset: 'custom', bands });
      });
      const label = document.createElement('div');
      label.className = 'eq-band-label';
      label.textContent = hz >= 1000 ? `${hz / 1000}k` : hz;
      col.append(slider, label);
      bandsWrap.appendChild(col);
    });
  });
  wrap.appendChild(bandsWrap);
  return wrap;
}

// Cheap update for high-frequency playback ticks — touches only the seek bar,
// time labels, and the active lyric line, never rebuilds a view.
export function renderPlaybackTick() {
  $('#np-current-time').textContent = formatTime(state.currentTime);
  const seekbar = $('#np-seekbar');
  if (document.activeElement !== seekbar) seekbar.value = state.currentTime || 0;
  $('#np-art-ring').style.setProperty('--play-progress', `${state.duration ? Math.min(100, state.currentTime / state.duration * 100) : 0}%`);
  const featureProgress = $('.now-playing-feature-progress span');
  if (featureProgress) featureProgress.style.width = `${state.duration ? Math.min(100, state.currentTime / state.duration * 100) : 0}%`;
  const featurePlay = $('.now-playing-feature-controls .feature-play');
  if (featurePlay) { featurePlay.textContent = state.isPlaying ? 'Ⅱ' : '▶'; featurePlay.title = state.isPlaying ? 'Pause' : 'Play'; }
  updateLyricHighlight();
  if (state.fullscreenPlayer) {
    $('#fullscreen-current').textContent = formatTime(state.currentTime);
    const fsSeek = $('#fullscreen-seek'); if (document.activeElement !== fsSeek) fsSeek.value = state.currentTime || 0;
    fsSeek.style.setProperty('--seek-progress', `${state.duration ? Math.min(100, state.currentTime / state.duration * 100) : 0}%`);
    updateTimedLyrics($('#fullscreen-lyrics'), 'fullscreen-lyric-line');
  }
}

// ---------------------------------------------------------------------------
// Toast
// ---------------------------------------------------------------------------

let toastTimer = null;
function renderToast() {
  if (!state.toast) return;
  const el = $('#toast');
  el.textContent = state.toast.message;
  el.className = 'toast' + (state.toast.kind !== 'info' ? ' ' + state.toast.kind : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { patch({ toast: null }); el.classList.add('hidden'); }, 4000);
}
