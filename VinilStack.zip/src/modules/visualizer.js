import { state } from './state.js';
import { getSpectrumInfo, getWaveformInfo, getVisualizerResponsiveness } from './player.js';

let active = false;
let frameId = 0;
let canvas;
let context;
let overlay;
let resizeHandler;
let palette = {};
let previousBandLevels = [];
let lastBandLayout = '';
let lastFrameTime = 0;
let pointerPosition = null;
let pointerMoveHandler;
let pointerLeaveHandler;

function formatFrequency(hz) {
  if (hz >= 1000) return `${(hz / 1000).toFixed(hz >= 10000 ? 1 : 2)} kHz`;
  return `${Math.round(hz)} Hz`;
}

function refreshPalette() {
  const styles = getComputedStyle(document.documentElement);
  palette = {
    background: styles.getPropertyValue('--bg-base').trim() || '#14171c',
    primary: styles.getPropertyValue('--text-primary').trim() || '#edeae3',
    muted: styles.getPropertyValue('--text-muted').trim() || '#8b8f97',
    accent: state.visualizerColor || '#fa2d55',
    grid: state.theme === 'light' ? 'rgba(32,29,23,.16)' : 'rgba(237,234,227,.16)',
    gridStrong: state.theme === 'light' ? 'rgba(32,29,23,.34)' : 'rgba(237,234,227,.34)',
    label: state.theme === 'light' ? 'rgba(32,29,23,.76)' : 'rgba(237,234,227,.76)'
  };
}

function resize() {
  if (!canvas || !context) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.max(1, Math.round(rect.width * dpr));
  canvas.height = Math.max(1, Math.round(rect.height * dpr));
  context.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function draw(time) {
  if (!active || !context) return;
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  if (!width || !height) { frameId = requestAnimationFrame(draw); return; }
  const deltaSeconds = lastFrameTime ? Math.min(0.1, Math.max(0.001, (time - lastFrameTime) / 1000)) : 1 / 60;
  lastFrameTime = time;
  palette.accent = state.visualizerColor || '#fa2d55';

  // Draw with the app's active theme colors so the analyzer feels like part
  // of Vinylstack instead of a separate utility window.
  context.clearRect(0, 0, width, height);
  context.fillStyle = palette.background || '#14171c';
  context.fillRect(0, 0, width, height);
  const sideInset = Math.max(54, Math.min(82, width * 0.07));
  const plot = {
    left: sideInset,
    top: Math.max(68, height * 0.08),
    right: width - sideInset,
    bottom: Math.min(height - 132, height * 0.88)
  };
  plot.bottom = Math.max(plot.top + 140, plot.bottom);
  const plotWidth = plot.right - plot.left;
  const plotHeight = plot.bottom - plot.top;
  const yForDb = (db) => plot.bottom - ((db + 100) / 100) * plotHeight;

  context.globalAlpha = 0.035;
  context.fillStyle = palette.accent || '#fa2d55';
  context.fillRect(plot.left, yForDb(-60), plotWidth, plot.bottom - yForDb(-60));
  context.globalAlpha = 1;

  context.font = '12px system-ui, sans-serif';
  context.textBaseline = 'middle';
  for (let db = 0; db >= -100; db -= 10) {
    const y = yForDb(db);
    context.beginPath();
    context.setLineDash(db === -60 ? [] : [2, 5]);
    context.strokeStyle = db === -60 ? palette.gridStrong : palette.grid;
    context.lineWidth = 1;
    context.moveTo(plot.left, y);
    context.lineTo(plot.right, y);
    context.stroke();
    context.setLineDash([]);
    context.fillStyle = palette.label;
    context.textAlign = 'right';
    context.fillText(String(db), plot.left - 12, y);
  }
  context.fillStyle = palette.muted;
  context.textAlign = 'left';
  context.fillText('dBFS', 14, plot.top - 16);

  const spectrum = getSpectrumInfo();
  const data = spectrum?.data;
  const sampleRate = spectrum?.sampleRate || 44100;
  const fftSize = spectrum?.fftSize || 2048;
  const binHz = sampleRate / fftSize;
  const lastUsableBin = data ? data.length - 1 : 0;
  const minFrequency = Math.max(20, binHz);
  const maxFrequency = Math.min(20000, lastUsableBin * binHz);
  const requestedBands = [60, 120, 204].includes(state.visualizerBands) ? state.visualizerBands : 120;
  const bands = [];
  const blackmanWindowPower = 0.3046; // mean square of the Web Audio Blackman window

  if (data && maxFrequency > minFrequency) {
    for (let i = 0; i < requestedBands; i += 1) {
      const lowHz = minFrequency * Math.pow(maxFrequency / minFrequency, i / requestedBands);
      const highHz = minFrequency * Math.pow(maxFrequency / minFrequency, (i + 1) / requestedBands);
      let firstBin = Math.max(1, Math.ceil(lowHz / binHz));
      let endBin = Math.min(data.length, i === requestedBands - 1
        ? Math.floor(highHz / binHz) + 1
        : Math.ceil(highHz / binHz));
      // Keep a bar in every selected slot. At low frequencies a requested
      // RTA interval can be narrower than one FFT bin; use its nearest bin.
      if (endBin <= firstBin) {
        const nearestBin = Math.max(1, Math.min(data.length - 1, Math.round(Math.sqrt(lowHz * highHz) / binHz)));
        firstBin = nearestBin;
        endBin = nearestBin + 1;
      }

      let powerSum = 0;
      let count = 0;
      for (let bin = firstBin; bin < endBin; bin += 1) {
        const binDb = data[bin];
        if (!Number.isFinite(binDb)) continue;
        const amplitude = 10 ** (binDb / 20);
        powerSum += amplitude * amplitude;
        count += 1;
      }
      // Integrate FFT-bin power (rather than averaging dB values) and correct
      // for the Blackman window so a full band reads as digital RMS dBFS.
      const bandDbfs = count && powerSum > 0
        ? Math.max(-100, Math.min(0, 10 * Math.log10((2 * powerSum) / blackmanWindowPower)))
        : -100;
      const centerHz = Math.sqrt((firstBin * binHz) * ((endBin - 1) * binHz));
      bands.push({ slot: i, centerHz, lowHz: firstBin * binHz, highHz: (endBin - 1) * binHz, dbfs: bandDbfs });
    }
  }

  const bandLayout = `${requestedBands}:${sampleRate}:${fftSize}:${width}:${minFrequency}:${maxFrequency}:${bands.length}`;
  if (bandLayout !== lastBandLayout) {
    previousBandLevels = bands.map(({ dbfs }) => dbfs);
    lastBandLayout = bandLayout;
  }
  const responsiveness = getVisualizerResponsiveness() / 100;
  const endpointBoost = 1 - 0.394 * responsiveness ** 3;
  const attackSeconds = (0.55 - responsiveness * 0.53) * endpointBoost;
  const releaseSeconds = (0.82 - responsiveness * 0.78) * endpointBoost;
  // Place each measured band in its original logarithmic slot so all bands
  // have identical width and identical gaps without distorting the axis.
  const bandSlotWidth = plotWidth / requestedBands;
  const barGap = Math.min(6, bandSlotWidth * 0.28);
  const barWidth = Math.max(1, bandSlotWidth - barGap);
  // Map the complete measurement range to the plot. Band centers can sit
  // inside the edges, but must not shrink the frequency axis as levels change.
  const xForFrequency = (hz) => plot.left + Math.log(hz / minFrequency) / Math.log(maxFrequency / minFrequency) * plotWidth;

  bands.forEach((band, i) => {
    const previous = previousBandLevels[i] ?? band.dbfs;
    const timeConstant = band.dbfs > previous ? attackSeconds : releaseSeconds;
    const smoothing = 1 - Math.exp(-deltaSeconds / timeConstant);
    const db = previous + (band.dbfs - previous) * smoothing;
    previousBandLevels[i] = db;
    const x = plot.left + band.slot * bandSlotWidth + barGap / 2;
    const y = yForDb(db);
    const barHeight = Math.max(1, plot.bottom - y);
    let color = palette.accent || '#fa2d55';
    if (db > -12) color = '#ffad18';
    if (db > -6) color = '#ff303b';
    context.fillStyle = color;
    context.globalAlpha = db <= -60 ? 0.62 : 1;
    context.fillRect(x, y, barWidth, barHeight);
    context.globalAlpha = 1;
  });

  let hoveredBand = null;
  if (pointerPosition && pointerPosition.y >= plot.top && pointerPosition.y <= plot.bottom) {
    let nearestDistance = Infinity;
    bands.forEach((band) => {
      const bandX = plot.left + band.slot * bandSlotWidth + bandSlotWidth / 2;
      const distance = Math.abs(bandX - pointerPosition.x);
      if (distance <= barWidth / 2 && distance < nearestDistance) {
        hoveredBand = band;
        nearestDistance = distance;
      }
    });
  }

  // Decade and octave markers follow the log-frequency RTA scale.
  const frequencyTicks = [20, 31.5, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000, 20000];
  const visibleTicks = frequencyTicks.filter((hz) => hz >= minFrequency && hz <= maxFrequency);
  context.font = '11px system-ui, sans-serif';
  context.textAlign = 'center';
  context.textBaseline = 'top';
  let lastLabelX = -Infinity;
  visibleTicks.forEach((hz, i) => {
    const x = xForFrequency(hz);
    const isEdge = i === 0 || i === visibleTicks.length - 1;
    if (x - lastLabelX < 38 && !isEdge) return;
    const label = hz >= 1000 ? `${(hz / 1000).toFixed(hz >= 10000 ? 0 : 1)}k` : `${Number.isInteger(hz) ? hz : hz.toFixed(1)} Hz`;
    context.strokeStyle = palette.grid;
    context.beginPath(); context.moveTo(x, plot.top); context.lineTo(x, plot.bottom); context.stroke();
    context.fillStyle = palette.label;
    context.fillText(label, x, plot.bottom + 10);
    lastLabelX = x;
  });
  context.textAlign = 'left';
  context.fillStyle = palette.muted;
  context.fillText('Frequency · logarithmic', plot.left, plot.bottom + 34);
  context.fillStyle = hoveredBand ? palette.primary : palette.muted;
  context.fillText(hoveredBand
    ? `${formatFrequency(hoveredBand.lowHz)}–${formatFrequency(hoveredBand.highHz)} · center ${formatFrequency(hoveredBand.centerHz)}`
    : 'Hover a band to inspect its frequency', plot.left, plot.bottom + 52);

  // RMS is measured directly from the time-domain samples for the header.
  const waveform = getWaveformInfo();
  const rmsDb = waveform?.rmsDbfs ?? -Infinity;
  // Compact RMS readout in the app's toolbar-like header.
  const peakLabel = document.getElementById('visualizer-peak');
  if (peakLabel) peakLabel.textContent = Number.isFinite(rmsDb) ? `${rmsDb.toFixed(1)} dBFS` : '−∞ dBFS';
  const rateLabel = document.getElementById('visualizer-rate');
  if (rateLabel) rateLabel.textContent = spectrum
    ? `RTA ${bands.length}/${requestedBands} bands · ${(sampleRate / 1000).toFixed(1)} kHz · ${Math.round(fftSize / 1024)}k FFT`
    : 'Waiting for audio';
  frameId = requestAnimationFrame(draw);
}

export function open() {
  if (active) return;
  overlay = document.getElementById('fullscreen-visualizer');
  canvas = document.getElementById('visualizer-canvas');
  context = canvas?.getContext('2d');
  if (!overlay || !canvas || !context) return;
  refreshPalette();
  active = true;
  lastFrameTime = 0;
  overlay.classList.add('open');
  overlay.setAttribute('aria-hidden', 'false');
  document.body.classList.add('visualizer-open');
  resize();
  resizeHandler = resize;
  window.addEventListener('resize', resizeHandler);
  pointerMoveHandler = (event) => {
    const rect = canvas.getBoundingClientRect();
    pointerPosition = { x: event.clientX - rect.left, y: event.clientY - rect.top };
  };
  pointerLeaveHandler = () => { pointerPosition = null; };
  canvas.addEventListener('pointermove', pointerMoveHandler);
  canvas.addEventListener('pointerleave', pointerLeaveHandler);
  frameId = requestAnimationFrame(draw);
  document.getElementById('visualizer-close')?.focus();
}

export function close() {
  if (!active) return;
  active = false;
  lastFrameTime = 0;
  cancelAnimationFrame(frameId);
  window.removeEventListener('resize', resizeHandler);
  canvas?.removeEventListener('pointermove', pointerMoveHandler);
  canvas?.removeEventListener('pointerleave', pointerLeaveHandler);
  pointerPosition = null;
  overlay.classList.remove('open');
  overlay.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('visualizer-open');
  document.getElementById('np-visualizer')?.focus();
}

export function isOpen() { return active; }
