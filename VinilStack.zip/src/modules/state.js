// state.js — a tiny observable store. Every view subscribes to the slices it
// cares about; every action mutates state through here so search results,
// the queue, playlists, favorites, and the library never drift apart.

const listeners = new Set();

function loadSearchHistory() {
  try {
    const value = JSON.parse(localStorage.getItem('vinylstack.searchHistory') || '[]');
    return Array.isArray(value) ? value.filter((item) => typeof item === 'string').slice(0, 12) : [];
  } catch (_) { return []; }
}

const state = {
  view: 'home',              // home | search | library | playlists | favorites | queue | settings
  activePlaylistId: null,

  searchQuery: '',
  searchResults: [],
  searchLoading: false,
  searchError: null,
  searchHistory: loadSearchHistory(),
  homeTab: 'for-you',
  homeRecommendations: [],
  homeRecommendationsLoading: false,
  homeRecommendationsLoaded: false,
  listeningProfile: { artists: {}, tokens: {}, tracks: {} },

  library: [],
  playlists: [],
  favorites: [],             // array of track ids
  recents: [],

  queue: { trackIds: [], currentIndex: -1, shuffle: false, repeat: 'off' },
  tracksById: {},            // id -> track object, populated as tracks are seen anywhere

  nowPlaying: null,          // track object currently loaded in the player
  playbackLoading: false,
  playbackError: null,
  isPlaying: false,
  currentTime: 0,
  duration: 0,
  volume: 1,
  playbackRate: 1,
  radio: { active: false, seedId: null, playedIds: [], failedIds: [], loading: false },

  lyrics: null,              // { synced, plain, source } for nowPlaying
  lyricsLoading: false,
  sidePanelOpen: false,
  sidePanelTab: 'queue',     // queue | lyrics | equalizer

  equalizer: { preset: 'flat', bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  theme: 'dark',
  accent: '#dcbc90',
  excludeVideos: false,
  visualizerResponsiveness: 75,
  visualizerColor: '#dcbc90',
  visualizerBands: 120,
  visualEffects: true,
  audioQuality: 'medium',

  sleepTimerMinutes: null,
  sleepTimerRemainingMs: null,

  binaries: { ytdlp: false, ffmpeg: false },
  autoUpdate: false,
  updateStatus: { status: 'idle', currentVersion: '', version: null, percent: 0, error: null },
  toast: null,
  fullscreenPlayer: false,

  listenTogether: { status: 'idle', serverUrl: 'wss://metroserverx.meowery.eu/ws', roomCode: null, userId: null, hostId: null, users: [], host: false }
};

function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function notify(changed) {
  for (const fn of listeners) fn(state, changed);
}

// High-frequency playback ticks (currentTime, ~4x/sec) go through a separate
// channel so they drive a cheap partial update instead of a full app re-render.
const tickListeners = new Set();
function onTick(fn) {
  tickListeners.add(fn);
  return () => tickListeners.delete(fn);
}
function tick(partial) {
  Object.assign(state, partial);
  for (const fn of tickListeners) fn(state);
}

// Shallow-patch the store and notify. Keeps call sites terse: patch({isPlaying:true})
function patch(partial) {
  Object.assign(state, partial);
  notify(partial);
}

// Remember a track's full metadata wherever it's first seen (search, resolve,
// download, playlist) so every other view can look it up by id alone.
function registerTracks(tracks) {
  const arr = Array.isArray(tracks) ? tracks : [tracks];
  for (const t of arr) {
    if (t && t.id) state.tracksById[t.id] = { ...state.tracksById[t.id], ...t };
  }
}

function getTrack(id) {
  return state.tracksById[id] || null;
}

function showToast(message, kind = 'info') {
  state.toast = { message, kind, at: Date.now() };
  notify({ toast: true });
}

export { state, subscribe, patch, notify, onTick, tick, registerTracks, getTrack, showToast };
