import { state, patch, registerTracks, getTrack, showToast } from './state.js';
import * as player from './player.js';
import * as listenTogether from './listenTogether.js';

const api = window.vinylstack;
const PLAYBACK_SESSION_KEY = 'vinylstack.playbackSession';
let lastSessionWriteAt = 0;
let pendingRadioSeed = null;

// ---------------------------------------------------------------------------
// Bootstrap — pull everything persisted in main process into live state
// ---------------------------------------------------------------------------

export async function bootstrap() {
  const [library, playlists, favorites, recents, queue, settings, binaries, updateStatus] = await Promise.all([
    api.store.get('library'),
    api.store.get('playlists'),
    api.store.get('favorites'),
    api.store.get('recents'),
    api.store.get('queue'),
    api.store.get('settings'),
    api.binaries.check(),
    api.updates.getState()
  ]);

  registerTracks(library);
  registerTracks(recents);
  registerTracks(playlists.flatMap((playlist) => playlist.tracks || []));

  const listeningProfile = loadListeningProfile(recents);

  patch({
    library, playlists, favorites, recents, queue, listeningProfile,
    equalizer: settings.equalizer,
    theme: settings.theme,
    accent: settings.accent === '#c97b3d' ? '#dcbc90' : (settings.accent || '#dcbc90'),
    visualEffects: settings.visualEffects !== false,
    excludeVideos: !!settings.excludeVideos,
    visualizerResponsiveness: Number.isFinite(settings.visualizerResponsiveness)
      ? Math.max(0, Math.min(100, settings.visualizerResponsiveness)) : 75,
    visualizerColor: /^#[0-9a-f]{6}$/i.test(settings.visualizerColor || '') ? settings.visualizerColor : '#dcbc90',
    visualizerBands: [60, 120, 204].includes(settings.visualizerBands) ? settings.visualizerBands : ({ low: 60, medium: 120, high: 204 }[settings.visualizerQuality] || 120),
    audioQuality: ['low', 'medium', 'high'].includes(settings.audioQuality) ? settings.audioQuality : 'medium',
    autoUpdate: !!settings.autoUpdate,
    updateStatus,
    volume: 1,
    playbackRate: settings.playbackRate || 1,
    binaries
  });

  document.documentElement.dataset.theme = settings.theme;
  document.documentElement.dataset.visualEffects = settings.visualEffects === false ? 'off' : 'on';
  const accent = settings.accent === '#c97b3d' ? '#dcbc90' : (settings.accent || '#dcbc90');
  document.documentElement.style.setProperty('--accent', accent);
  if (accent !== settings.accent) await patchSettings({ accent });
  player.setVolume(1);
  if (settings.volume !== 1) await patchSettings({ volume: 1 });
  player.setPlaybackRate(settings.playbackRate || 1);
  player.applyEqualizer(settings.equalizer);
  player.setVisualizerResponsiveness(Number.isFinite(settings.visualizerResponsiveness)
    ? Math.max(0, Math.min(100, settings.visualizerResponsiveness)) : 75);

  if (!binaries.ytdlp) {
    showToast('yt-dlp was not detected \u2014 open Settings to fix it.', 'warn');
  }
  if (!binaries.ffmpeg) {
    showToast('ffmpeg was not detected \u2014 downloads will fail until it\u2019s fixed in Settings.', 'warn');
  }

  // Restore queue metadata immediately; the player source itself is restored
  // asynchronously below because streamed URLs expire between app sessions.
  if (queue.trackIds.length && queue.currentIndex >= 0) {
    const id = queue.trackIds[queue.currentIndex];
    const track = getTrack(id) || state.library.find((t) => t.id === id);
    if (track) patch({ nowPlaying: track, duration: track.duration || 0 });
  }
  restorePlaybackSession();
}

export function savePlaybackSession(force = false) {
  if (!state.nowPlaying?.id) return;
  const now = Date.now();
  if (!force && now - lastSessionWriteAt < 4000) return;
  lastSessionWriteAt = now;
  const { id, title, artist, duration, thumbnail, filePath } = state.nowPlaying;
  try {
    localStorage.setItem(PLAYBACK_SESSION_KEY, JSON.stringify({
      track: { id, title, artist, duration, thumbnail, ...(filePath ? { filePath } : {}) },
      position: Math.max(0, Number(state.currentTime) || 0),
      savedAt: now
    }));
  } catch (_) {}
}

async function restorePlaybackSession() {
  let session;
  try { session = JSON.parse(localStorage.getItem(PLAYBACK_SESSION_KEY) || 'null'); } catch (_) { return; }
  const track = session?.track || state.nowPlaying;
  if (!track?.id || !track.title) return;
  const storedTrack = getTrack(track.id);
  const restored = { ...storedTrack, ...track };
  registerTracks(restored);
  const queueIndex = state.queue.trackIds.indexOf(restored.id);
  if (queueIndex >= 0) persistQueue({ ...state.queue, currentIndex: queueIndex });
  else setQueueToSingle(restored.id);
  const position = Math.max(0, Number(session?.position) || 0);
  patch({ nowPlaying: restored, currentTime: position, duration: restored.duration || 0, isPlaying: false, playbackLoading: false, playbackError: null });
  if (restored.filePath) {
    player.loadSource(localFileUrl(restored.filePath), restored.duration || 0, position);
    return;
  }
  if (!state.binaries.ytdlp) return;
  try {
    const resolved = await resolveStream(restored, true);
    if (state.nowPlaying?.id !== restored.id) return;
    const refreshed = { ...restored, ...resolved };
    registerTracks(refreshed);
    patch({ nowPlaying: refreshed, duration: resolved.duration || restored.duration || 0 });
    player.loadSource(resolved.streamUrl, resolved.duration || restored.duration || 0, position);
    player.setPlaybackRate(state.playbackRate);
  } catch (_) {
    // Keep the saved track visible; the user can retry it from the player.
  }
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------

let searchDebounce = null;
let searchRequestId = 0;
export function queueSearch(query) {
  query = cleanQuery(query);
  const requestId = ++searchRequestId;
  patch({ searchQuery: query, searchLoading: !!query.trim(), searchError: null });
  clearTimeout(searchDebounce);
  if (!query.trim()) { patch({ searchResults: [], searchError: null }); return; }
  searchDebounce = setTimeout(() => runSearch(query, requestId), 250);
}

export async function runSearch(query, requestId = ++searchRequestId) {
  query = cleanQuery(query);
  if (requestId !== searchRequestId) return;
  if (!query) { if (requestId === searchRequestId) patch({ searchResults: [], searchLoading: false, searchError: null }); return; }
  if (!state.binaries.ytdlp) {
    if (requestId === searchRequestId) patch({ searchLoading: false, searchError: 'yt-dlp is not installed or not on your PATH.' });
    return;
  }
  const history = [query, ...state.searchHistory.filter((item) => item.toLowerCase() !== query.toLowerCase())].slice(0, 12);
  try { localStorage.setItem('vinylstack.searchHistory', JSON.stringify(history)); } catch (_) {}
  patch({ searchHistory: history, searchLoading: true, searchError: null });
  try {
    const results = await api.ytdlp.search(query, 25, { excludeVideos: state.excludeVideos });
    if (requestId !== searchRequestId) return;
    registerTracks(results);
    patch({ searchResults: results, searchLoading: false });
  } catch (err) {
    if (requestId !== searchRequestId) return;
    patch({ searchLoading: false, searchError: err.message || String(err) });
  }
}

export function clearSearchHistory() {
  try { localStorage.removeItem('vinylstack.searchHistory'); } catch (_) {}
  patch({ searchHistory: [] });
}

export async function loadHomeRecommendations({ refresh = false } = {}) {
  if (state.homeRecommendationsLoading || (state.homeRecommendationsLoaded && !refresh)) return;
  if (!state.binaries.ytdlp) {
    patch({ homeRecommendations: [], homeRecommendationsLoading: false, homeRecommendationsLoaded: true });
    return;
  }
  patch({ homeRecommendationsLoading: true, homeRecommendationsLoaded: false });
  try {
    const favoriteTracks = state.favorites.map((id) => getTrack(id)).filter(Boolean);
    const favoriteProfile = profileFromTracks(favoriteTracks, 2);
    const profile = mergeProfiles(state.listeningProfile, favoriteProfile);
    const artists = Object.entries(profile.artists).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([artist]) => artist);
    if (!artists.length) {
      patch({ homeRecommendations: [], homeRecommendationsLoading: false, homeRecommendationsLoaded: true });
      return;
    }
    const seen = new Set([...state.recents.map((track) => track.id), ...state.favorites]);
    const candidates = new Map();
    const searchResults = await Promise.all(artists.map((artist) =>
      api.ytdlp.search(`popular songs by ${artist}`, 20, { excludeVideos: state.excludeVideos }).catch(() => [])
    ));
    for (const found of searchResults) {
      for (const track of found) {
        if (!track?.id || seen.has(track.id) || !track.duration || track.duration < 30 || track.duration > 900) continue;
        const artistKey = normalizeAffinity(track.artist);
        const artistScore = profile.artists[artistKey] || 0;
        const tokenScore = affinityTokens(track.title).reduce((score, token) => score + (profile.tokens[token] || 0), 0);
        const score = artistScore * 3 + tokenScore;
        const prior = candidates.get(track.id);
        if (!prior || score > prior.score) candidates.set(track.id, { track, score });
      }
    }
    const recommended = [];
    const artistCounts = new Map();
    for (const { track } of [...candidates.values()].sort((a, b) => b.score - a.score)) {
      const artist = normalizeAffinity(track.artist);
      const count = artistCounts.get(artist) || 0;
      if (count >= 3) continue;
      artistCounts.set(artist, count + 1);
      recommended.push(track);
      if (recommended.length >= 16) break;
    }
    registerTracks(recommended);
    patch({ homeRecommendations: recommended, homeRecommendationsLoading: false, homeRecommendationsLoaded: true });
  } catch (_) {
    patch({ homeRecommendations: [], homeRecommendationsLoading: false, homeRecommendationsLoaded: true });
  }
}

export function setHomeTab(homeTab) { patch({ homeTab }); }

// ---------------------------------------------------------------------------
// Playback — resolves a fresh stream URL just before playing, since
// yt-dlp URLs expire; queue navigation always routes through here.
// ---------------------------------------------------------------------------

let playbackRequestId = 0;
let mediaErrorRetriedTrackId = null;
const streamCache = new Map();
const STREAM_CACHE_TTL_MS = 120_000;

function resolveStream(track, fresh = false) {
  let cached = streamCache.get(track.id);
  if (fresh || (cached?.resolvedAt && Date.now() - cached.resolvedAt > STREAM_CACHE_TTL_MS)) {
    streamCache.delete(track.id);
    cached = null;
  }
  if (cached) return cached.promise;
  const entry = { promise: null, resolvedAt: 0 };
  entry.promise = api.ytdlp.resolve(track.id).then((resolved) => {
    entry.resolvedAt = Date.now();
    registerTracks(resolved);
    return resolved;
  }).catch((error) => {
    if (streamCache.get(track.id) === entry) streamCache.delete(track.id);
    throw error;
  });
  streamCache.set(track.id, entry);
  while (streamCache.size > 8) streamCache.delete(streamCache.keys().next().value);
  return entry.promise;
}

function prefetchNextStream() {
  if (!state.binaries.ytdlp) return;
  const nextId = state.queue.trackIds[state.queue.currentIndex + 1];
  const next = nextId && getTrack(nextId);
  if (next && !next.filePath) resolveStream(next).catch(() => {});
}

export function prefetchNextTrack() {
  const remaining = (state.duration || 0) - (state.currentTime || 0);
  if (remaining > 45) return;
  prefetchNextStream();
}

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function localFileUrl(filePath) {
  const normalized = String(filePath).replace(/\\/g, '/');
  if (/^[A-Za-z]:\//.test(normalized)) {
    return `file:///${normalized[0]}:${normalized.slice(2).split('/').map(encodeURIComponent).join('/')}`;
  }
  return `file://${normalized.split('/').map(encodeURIComponent).join('/')}`;
}

export async function playTrack(trackOrId, { fromQueue = false, recovery = false } = {}) {
  const base = typeof trackOrId === 'string' ? getTrack(trackOrId) : trackOrId;
  if (!base) return;
  const requestId = ++playbackRequestId;
  if (!recovery) mediaErrorRetriedTrackId = null;
  player.pause();
  registerTracks(base);
  patch({ nowPlaying: base, currentTime: 0, duration: base.duration || 0, isPlaying: false, playbackLoading: !base.filePath, playbackError: null });
  savePlaybackSession(true);
  pushRecent(base);
  if (state.radio.active) {
    const playedIds = [...new Set([...(state.radio.playedIds || []), base.id])];
    patch({ radio: { ...state.radio, playedIds } });
  }

  if (!fromQueue) setQueueToSingle(base.id);

  if (base.filePath) {
    // local/downloaded file — plays instantly, no network needed
    player.loadSource(localFileUrl(base.filePath), base.duration || 0);
    const started = await player.play();
    if (requestId !== playbackRequestId) return;
    patch({ isPlaying: started, playbackLoading: false, playbackError: started ? null : 'Playback could not start.' });
    if (!started) {
      showToast(`Couldn’t play “${base.title}”.${fromQueue && state.queue.currentIndex < state.queue.trackIds.length - 1 ? ' Skipping to the next song.' : ' Try again.'}`, 'error');
      if (fromQueue && state.queue.currentIndex < state.queue.trackIds.length - 1) skipNext();
      return;
    }
    listenTogether.onLocalPlayback('change_track');
    listenTogether.onLocalPlayback('play', { position: 0 });
    fetchLyricsFor(base);
    if (!fromQueue && !recovery && state.binaries.ytdlp) startRadio(base, { playSeed: false });
    return;
  }

  if (!state.binaries.ytdlp) {
    patch({ playbackLoading: false, playbackError: 'yt-dlp is required to stream this song.' });
    showToast('yt-dlp is required to stream this track.', 'warn');
    return;
  }

  let lastError;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      if (attempt) await wait(350);
      if (requestId !== playbackRequestId) return;
      const resolved = await resolveStream(base, attempt > 0);
      if (requestId !== playbackRequestId) return;
      if (!resolved.streamUrl) throw new Error('No playable audio stream was returned.');
      patch({ nowPlaying: { ...base, ...resolved }, duration: resolved.duration || base.duration || 0 });
      player.loadSource(resolved.streamUrl, resolved.duration || base.duration || 0);
      player.setPlaybackRate(state.playbackRate);
      const started = await player.play();
      if (requestId !== playbackRequestId) return;
      if (!started) throw new Error('The audio player could not start the stream.');
      patch({ isPlaying: true, playbackLoading: false, playbackError: null });
      listenTogether.onLocalPlayback('change_track');
      listenTogether.onLocalPlayback('play', { position: 0 });
      fetchLyricsFor(base);
      prefetchNextStream();
      if (!fromQueue && !recovery) startRadio(base, { playSeed: false });
      return;
    } catch (err) {
      if (requestId !== playbackRequestId) return;
      lastError = err;
    }
  }
  patch({ isPlaying: false, playbackLoading: false, playbackError: lastError?.message || 'Stream could not be loaded.' });
  showToast(`Couldn’t play “${base.title}”. Retried the stream; ${fromQueue && state.queue.currentIndex < state.queue.trackIds.length - 1 ? 'skipping to the next song.' : 'try selecting it again.'}`, 'error');
  if (state.radio.active) {
    patch({ radio: { ...state.radio, failedIds: [...new Set([...(state.radio.failedIds || []), base.id])] } });
    skipNext();
  } else if (fromQueue && state.queue.currentIndex < state.queue.trackIds.length - 1) skipNext();
}

export async function togglePlayPause() {
  if (!state.nowPlaying) return;
  if (state.playbackLoading) return;
  if (state.isPlaying) { player.pause(); patch({ isPlaying: false }); listenTogether.onLocalPlayback('pause', { position: state.currentTime }); }
  else {
    const started = await player.play();
    if (started) { patch({ isPlaying: true }); listenTogether.onLocalPlayback('play', { position: state.currentTime }); }
    else { patch({ isPlaying: false }); showToast('Playback could not start. Try selecting the song again.', 'error'); }
  }
}

export function handlePlaybackError() {
  if (state.playbackLoading || !state.nowPlaying?.id) return;
  const failedTrack = state.nowPlaying;
  if (!state.radio.active) {
    if (mediaErrorRetriedTrackId === failedTrack.id) {
      showToast(`Couldn’t play “${failedTrack.title}”. Try selecting the song again.`, 'error');
      return;
    }
    mediaErrorRetriedTrackId = failedTrack.id;
    streamCache.delete(failedTrack.id);
    showToast(`Refreshing the stream for “${failedTrack.title}”…`, 'warn');
    playTrack(failedTrack, { fromQueue: state.queue.trackIds[state.queue.currentIndex] === failedTrack.id, recovery: true });
    return;
  }
  const failedIds = [...new Set([...(state.radio.failedIds || []), state.nowPlaying.id])];
  patch({ radio: { ...state.radio, failedIds } });
  showToast('This station track failed to play. Skipping to the next one.', 'warn');
  skipNext();
}

function pushRecent(track) {
  const recents = [track, ...state.recents.filter((t) => t.id !== track.id)].slice(0, 50);
  const listeningProfile = observeListening(track, state.listeningProfile);
  patch({ recents, listeningProfile, homeRecommendationsLoaded: false });
  api.store.set('recents', recents);
}

const PROFILE_KEY = 'vinylstack.listeningProfile';
const AFFINITY_STOP_WORDS = new Set(['the','and','with','from','that','this','song','official','audio','video','lyrics','feat','ft','remix','live','version','music','by']);

function normalizeAffinity(value) { return String(value || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim(); }
function affinityTokens(value) {
  return normalizeAffinity(value).split(/\s+/).filter((token) => token.length > 2 && !AFFINITY_STOP_WORDS.has(token));
}
function emptyProfile() { return { artists: {}, tokens: {}, tracks: {} }; }
function profileFromTracks(tracks, weight = 1) {
  const profile = emptyProfile();
  for (const track of tracks) {
    if (!track) continue;
    const artist = normalizeAffinity(track.artist);
    if (artist && artist !== 'unknown artist') profile.artists[artist] = (profile.artists[artist] || 0) + weight;
    for (const token of affinityTokens(track.title)) profile.tokens[token] = (profile.tokens[token] || 0) + weight;
  }
  return profile;
}
function mergeProfiles(first = emptyProfile(), second = emptyProfile()) {
  const merged = emptyProfile();
  for (const key of ['artists', 'tokens', 'tracks']) {
    for (const source of [first[key] || {}, second[key] || {}]) {
      for (const [name, score] of Object.entries(source)) merged[key][name] = (merged[key][name] || 0) + (Number(score) || 0);
    }
  }
  return merged;
}
function loadListeningProfile(recents) {
  try {
    const saved = JSON.parse(localStorage.getItem(PROFILE_KEY) || 'null');
    if (saved && typeof saved === 'object') return mergeProfiles(emptyProfile(), saved);
  } catch (_) {}
  const seeded = profileFromTracks([...recents].reverse());
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(seeded)); } catch (_) {}
  return seeded;
}
function observeListening(track, current) {
  const next = mergeProfiles(current, profileFromTracks([track]));
  next.tracks[track.id] = (next.tracks[track.id] || 0) + 1;
  // Bound local profile growth while preserving long-term artist/token taste.
  for (const key of ['artists', 'tokens']) {
    const entries = Object.entries(next[key]).sort((a, b) => b[1] - a[1]).slice(0, 120);
    next[key] = Object.fromEntries(entries.map(([name, score]) => [name, Math.round(score * 100) / 100]));
  }
  next.tracks = Object.fromEntries(Object.entries(next.tracks).sort((a, b) => b[1] - a[1]).slice(0, 500));
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(next)); } catch (_) {}
  return next;
}

// ---------------------------------------------------------------------------
// Queue
// ---------------------------------------------------------------------------

function persistQueue(queue) {
  patch({ queue });
  api.store.set('queue', queue);
}

export function setQueueToSingle(trackId) {
  persistQueue({ ...state.queue, trackIds: [trackId], currentIndex: 0 });
}

export function clearQueue() {
  const currentId = state.queue.trackIds[state.queue.currentIndex] || state.nowPlaying?.id || null;
  if (state.radio.active) stopRadio();
  persistQueue({ ...state.queue, trackIds: currentId ? [currentId] : [], currentIndex: currentId ? 0 : -1 });
  listenTogether.onLocalPlayback('sync_queue');
  showToast('Up Next queue cleared');
}

export function addToQueue(trackOrTracks) {
  const arr = Array.isArray(trackOrTracks) ? trackOrTracks : [trackOrTracks];
  registerTracks(arr);
  const ids = arr.map((t) => t.id);
  const trackIds = [...state.queue.trackIds, ...ids];
  persistQueue({ ...state.queue, trackIds });
  showToast(ids.length > 1 ? `Added ${ids.length} tracks to queue` : 'Added to queue');
}

export function playNext(trackOrTracks) {
  const arr = Array.isArray(trackOrTracks) ? trackOrTracks : [trackOrTracks];
  registerTracks(arr);
  const ids = arr.map((t) => t.id);
  const insertAt = state.queue.currentIndex + 1;
  const trackIds = [...state.queue.trackIds];
  trackIds.splice(insertAt, 0, ...ids);
  persistQueue({ ...state.queue, trackIds });
}

export function removeFromQueue(index) {
  const trackIds = state.queue.trackIds.filter((_, i) => i !== index);
  let currentIndex = state.queue.currentIndex;
  if (index < currentIndex) currentIndex -= 1;
  persistQueue({ ...state.queue, trackIds, currentIndex });
}

export function reorderQueue(fromIndex, toIndex) {
  const trackIds = [...state.queue.trackIds];
  const [moved] = trackIds.splice(fromIndex, 1);
  trackIds.splice(toIndex, 0, moved);
  let currentIndex = state.queue.currentIndex;
  if (fromIndex === currentIndex) currentIndex = toIndex;
  else {
    if (fromIndex < currentIndex) currentIndex -= 1;
    if (toIndex <= currentIndex) currentIndex += 1;
  }
  persistQueue({ ...state.queue, trackIds, currentIndex });
}

export function toggleShuffle() {
  persistQueue({ ...state.queue, shuffle: !state.queue.shuffle });
  listenTogether.onLocalPlayback('sync_queue');
}

export function cycleRepeat() {
  const order = ['off', 'all', 'one'];
  const next = order[(order.indexOf(state.queue.repeat) + 1) % order.length];
  persistQueue({ ...state.queue, repeat: next });
  listenTogether.onLocalPlayback('sync_queue');
}

export function playQueueIndex(index) {
  const { trackIds } = state.queue;
  if (index < 0 || index >= trackIds.length) return;
  persistQueue({ ...state.queue, currentIndex: index });
  playTrack(trackIds[index], { fromQueue: true });
}

export function skipNext() {
  const { trackIds, currentIndex, shuffle, repeat } = state.queue;
  if (!trackIds.length) return;
  if (repeat === 'one') { playQueueIndex(currentIndex); return; }
  let next;
  if (shuffle) {
    next = trackIds.length > 1
      ? (currentIndex + 1 + Math.floor(Math.random() * (trackIds.length - 1))) % trackIds.length
      : 0;
  } else {
    next = currentIndex + 1;
    if (next >= trackIds.length) {
      if (repeat === 'all') next = 0;
      else if (state.radio.active) {
        player.pause(); patch({ isPlaying: false });
        extendRadioIfNeeded().then(() => {
          if (state.queue.currentIndex < state.queue.trackIds.length - 1) skipNext();
        });
        return;
      } else { player.pause(); patch({ isPlaying: false }); return; }
    }
  }
  playQueueIndex(next);
}

export function skipPrev() {
  const { trackIds, currentIndex } = state.queue;
  if (!trackIds.length) return;
  if (state.currentTime > 3) { player.seek(0); return; }
  const prev = currentIndex - 1 < 0 ? (state.queue.repeat === 'all' ? trackIds.length - 1 : 0) : currentIndex - 1;
  playQueueIndex(prev);
}

// ---------------------------------------------------------------------------
// Radio — lightweight YouTube-style station from the current artist/title
// ---------------------------------------------------------------------------

let radioBusy = false;
let radioSeedId = null;
let radioGeneration = 0;

function cleanQuery(q) {
  return String(q ?? '').replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
}

function radioQueries(seed) {
  // Keep the seed query quoted as a normal search phrase. yt-dlp receives it
  // as ONE argv entry; main.js deliberately does not invoke a shell.
  return [
    cleanQuery(`${seed.artist} ${seed.title}`),
    cleanQuery(`${seed.artist} official songs`),
    cleanQuery(`songs like ${seed.title} ${seed.artist}`),
    cleanQuery(`${seed.artist} related artists`),
  ].filter(Boolean);
}

export async function startRadio(seed = state.nowPlaying, { append = false, playSeed = true } = {}) {
  if (!seed) { showToast('Play a song first to start a radio station.', 'warn'); return; }
  if (!state.binaries.ytdlp) { showToast('yt-dlp is required for radio.', 'warn'); return; }
  if (radioBusy) {
    if (!append) { pendingRadioSeed = seed; radioGeneration++; }
    return;
  }
  radioBusy = true;
  if (!append) radioGeneration++;
  const generation = radioGeneration;
  radioSeedId = seed.id;
  patch({ radio: append
    ? { ...state.radio, active: true, seedId: seed.id, loading: true }
    : { active: true, seedId: seed.id, playedIds: [seed.id], failedIds: [], loading: true } });
  showToast(`Creating a radio station from “${seed.title}”…`);
  try {
    const existing = new Set([
      ...(state.queue.trackIds || []),
      ...(state.radio.playedIds || []),
      ...(state.radio.failedIds || [])
    ]);
    existing.add(seed.id);
    const results = [];
    for (const q of radioQueries(seed)) {
      const found = await api.ytdlp.search(q, 20, { excludeVideos: state.excludeVideos }).catch(() => []);
      if (generation !== radioGeneration) return;
      for (const t of found) {
        if (!t?.id || existing.has(t.id) || !t.duration || t.duration < 30 || t.duration > 900) continue;
        existing.add(t.id);
        results.push(t);
      }
      if (results.length >= 24) break;
    }
    if (!results.length) throw new Error('No related songs were found.');
    registerTracks(results);
    const ids = append ? [...state.queue.trackIds, ...results.map(t => t.id)] : [seed.id, ...results.map(t => t.id)];
    persistQueue({ ...state.queue, trackIds: ids, currentIndex: append ? state.queue.currentIndex : 0 });
    patch({ radio: { ...state.radio, active: true, loading: false } });
    prefetchNextStream();
    if (!append && playSeed) await playTrack(seed, { fromQueue: true });
    showToast(`Radio ready · ${results.length} related songs queued`);
  } catch (err) {
    if (generation !== radioGeneration) return;
    patch({ radio: { ...state.radio, active: append ? state.radio.active : false, loading: false } });
    showToast(`Radio couldn’t be created: ${err.message || err}`, 'error');
  } finally {
    radioBusy = false;
    if (pendingRadioSeed) {
      const nextSeed = pendingRadioSeed;
      pendingRadioSeed = null;
      if (nextSeed.id !== state.nowPlaying?.id) return;
      startRadio(nextSeed, { playSeed: false });
    }
  }
}

export async function extendRadioIfNeeded() {
  if (!state.radio.active || !radioSeedId || radioBusy) return;
  const { trackIds, currentIndex } = state.queue;
  if (currentIndex < 0 || trackIds.length - currentIndex > 4) return;
  const seed = getTrack(radioSeedId) || state.nowPlaying;
  if (seed) await startRadio(seed, { append: true });
}

export function stopRadio() {
  radioGeneration++;
  radioSeedId = null;
  patch({ radio: { ...state.radio, active: false, loading: false } });
}

export async function setPlaybackRate(rate) {
  const playbackRate = Math.max(0.5, Math.min(2, Math.round(rate * 20) / 20));
  patch({ playbackRate });
  player.setPlaybackRate(playbackRate);
  const settings = await api.store.get('settings');
  await api.store.set('settings', { ...settings, playbackRate });
}

export { listenTogether };

// ---------------------------------------------------------------------------
// Library / downloads
// ---------------------------------------------------------------------------

export async function downloadTrack(track) {
  if (!state.binaries.ytdlp || !state.binaries.ffmpeg) {
    showToast('Downloading needs both yt-dlp and ffmpeg installed.', 'warn');
    return;
  }
  showToast(`Downloading "${track.title}"\u2026`);
  try {
    const entry = await api.ytdlp.download(track.id, track);
    registerTracks(entry);
    const library = [entry, ...state.library.filter((t) => t.id !== entry.id)];
    patch({ library });
    showToast(`Saved "${entry.title}" to your library`);
  } catch (err) {
    showToast(`Download failed: ${err.message || err}`, 'error');
  }
}

export async function removeFromLibrary(trackId) {
  const library = await api.fs.removeLibraryFile(trackId);
  patch({ library });
}

export function isDownloaded(trackId) {
  return state.library.some((t) => t.id === trackId);
}

// ---------------------------------------------------------------------------
// Playlists
// ---------------------------------------------------------------------------

function persistPlaylists(playlists) {
  patch({ playlists });
  api.store.set('playlists', playlists);
}

export function createPlaylist(name) {
  const playlist = { id: `pl_${Date.now()}`, name: name.trim() || 'Untitled playlist', trackIds: [], createdAt: Date.now() };
  persistPlaylists([playlist, ...state.playlists]);
  return playlist;
}

export async function importYoutubeMusicPlaylist(url) {
  if (!state.binaries.ytdlp) throw new Error('yt-dlp is required to import YouTube Music playlists. Set it up in Settings first.');
  const imported = await api.ytdlp.importPlaylist(url);
  const uniqueTracks = [...new Map(imported.tracks.map((track) => [track.id, track])).values()];
  registerTracks(uniqueTracks);
  const playlist = { id: `pl_${Date.now()}`, name: imported.name, trackIds: uniqueTracks.map((track) => track.id), tracks: uniqueTracks, createdAt: Date.now(), importedFrom: 'YouTube Music' };
  persistPlaylists([playlist, ...state.playlists]);
  showToast(`Imported ${uniqueTracks.length} songs`);
  return playlist;
}

export async function playPlaylist(playlistId, { shuffle = false } = {}) {
  const playlist = state.playlists.find((item) => item.id === playlistId);
  if (!playlist) return;
  const tracks = playlist.trackIds.map((id) => getTrack(id)).filter(Boolean);
  if (!tracks.length) { showToast('This playlist has no playable songs.', 'warn'); return; }
  if (state.radio.active) stopRadio();
  const order = [...tracks];
  if (shuffle) {
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
  }
  persistQueue({ ...state.queue, trackIds: order.map((track) => track.id), currentIndex: 0, shuffle: false });
  return playTrack(order[0], { fromQueue: true });
}

export function deletePlaylist(playlistId) {
  persistPlaylists(state.playlists.filter((p) => p.id !== playlistId));
  if (state.activePlaylistId === playlistId) patch({ activePlaylistId: null, view: 'playlists' });
}

export function renamePlaylist(playlistId, name) {
  persistPlaylists(state.playlists.map((p) => (p.id === playlistId ? { ...p, name } : p)));
}

export function addToPlaylist(playlistId, track) {
  registerTracks(track);
  persistPlaylists(state.playlists.map((p) =>
    p.id === playlistId && !p.trackIds.includes(track.id)
      ? { ...p, trackIds: [...p.trackIds, track.id] }
      : p
  ));
  showToast(`Added to ${state.playlists.find((p) => p.id === playlistId)?.name || 'playlist'}`);
}

export function removeFromPlaylist(playlistId, trackId) {
  persistPlaylists(state.playlists.map((p) =>
    p.id === playlistId ? { ...p, trackIds: p.trackIds.filter((id) => id !== trackId) } : p
  ));
}

// ---------------------------------------------------------------------------
// Favorites
// ---------------------------------------------------------------------------

export function toggleFavorite(track) {
  registerTracks(track);
  const has = state.favorites.includes(track.id);
  const favorites = has ? state.favorites.filter((id) => id !== track.id) : [...state.favorites, track.id];
  patch({ favorites, homeRecommendationsLoaded: false });
  api.store.set('favorites', favorites);
}

export function isFavorite(trackId) {
  return state.favorites.includes(trackId);
}

// ---------------------------------------------------------------------------
// Lyrics
// ---------------------------------------------------------------------------

export async function fetchLyricsFor(track) {
  patch({ lyrics: null, lyricsLoading: true });
  try {
    const lyrics = await api.lyrics.fetch(track.title, track.artist, track.duration);
    if (state.nowPlaying?.id !== track.id) return; // track changed while we were fetching
    patch({ lyrics, lyricsLoading: false });
  } catch (_) {
    if (state.nowPlaying?.id === track.id) patch({ lyrics: null, lyricsLoading: false });
  }
}

// ---------------------------------------------------------------------------
// Settings — theme, accent, equalizer, volume, sleep timer, download dir
// ---------------------------------------------------------------------------

async function patchSettings(partial) {
  const current = await api.store.get('settings');
  const next = { ...current, ...partial };
  await api.store.set('settings', next);
  return next;
}

export async function setTheme(theme) {
  patch({ theme });
  document.documentElement.dataset.theme = theme;
  await patchSettings({ theme });
}

export async function setAccent(accent) {
  patch({ accent });
  document.documentElement.style.setProperty('--accent', accent);
  await patchSettings({ accent });
}

export async function setVisualEffects(visualEffects) {
  visualEffects = !!visualEffects;
  patch({ visualEffects });
  document.documentElement.dataset.visualEffects = visualEffects ? 'on' : 'off';
  await patchSettings({ visualEffects });
}

export async function setEqualizer(eq) {
  patch({ equalizer: eq });
  player.applyEqualizer(eq);
  await patchSettings({ equalizer: eq });
}

export async function setVolume(volume) {
  patch({ volume });
  player.setVolume(volume);
  await patchSettings({ volume });
}

export async function setExcludeVideos(excludeVideos) {
  excludeVideos = !!excludeVideos;
  patch({ excludeVideos });
  await patchSettings({ excludeVideos });
}

export function previewVisualizerResponsiveness(value) {
  player.setVisualizerResponsiveness(value);
}

export async function setVisualizerResponsiveness(value) {
  const visualizerResponsiveness = Math.round(Math.max(0, Math.min(100, Number(value) || 0)));
  patch({ visualizerResponsiveness });
  player.setVisualizerResponsiveness(visualizerResponsiveness);
  await patchSettings({ visualizerResponsiveness });
}

export async function setVisualizerColor(color) {
  if (!/^#[0-9a-f]{6}$/i.test(String(color || ''))) return;
  const visualizerColor = String(color).toLowerCase();
  patch({ visualizerColor });
  await patchSettings({ visualizerColor });
}

export async function setVisualizerBands(bands) {
  bands = Number(bands);
  if (![60, 120, 204].includes(bands)) return;
  patch({ visualizerBands: bands });
  await patchSettings({ visualizerBands: bands });
}

export async function setAudioQuality(quality) {
  if (!['low', 'medium', 'high'].includes(quality)) return;
  patch({ audioQuality: quality });
  streamCache.clear();
  await patchSettings({ audioQuality: quality });
}

export async function chooseDownloadDir() {
  const dir = await api.fs.chooseDownloadDir();
  if (dir) showToast(`Downloads will be saved to ${dir}`);
  return dir;
}

export async function recheckBinaries() {
  const binaries = await api.binaries.check();
  patch({ binaries });
  if (binaries.ytdlp && binaries.ffmpeg) showToast('yt-dlp and ffmpeg are both detected.');
  else showToast('Still missing ' + [!binaries.ytdlp && 'yt-dlp', !binaries.ffmpeg && 'ffmpeg'].filter(Boolean).join(' and ') + '.', 'warn');
  return binaries;
}

export async function locateBinary(type) {
  const binaries = await api.fs.locateBinary(type);
  if (binaries) {
    patch({ binaries });
    const ok = type === 'ffmpeg' ? binaries.ffmpeg : binaries.ytdlp;
    showToast(ok ? `${type === 'ffmpeg' ? 'ffmpeg' : 'yt-dlp'} found and working.` : `That file didn\u2019t work as ${type === 'ffmpeg' ? 'ffmpeg' : 'yt-dlp'} — double check the path.`, ok ? 'info' : 'error');
  }
  return binaries;
}

let sleepTimerHandle = null;
export function setSleepTimer(minutes) {
  clearInterval(sleepTimerHandle);
  if (!minutes) { patch({ sleepTimerMinutes: null, sleepTimerRemainingMs: null }); return; }
  const endsAt = Date.now() + minutes * 60000;
  patch({ sleepTimerMinutes: minutes, sleepTimerRemainingMs: minutes * 60000 });
  sleepTimerHandle = setInterval(() => {
    const remaining = endsAt - Date.now();
    if (remaining <= 0) {
      clearInterval(sleepTimerHandle);
      player.pause();
      patch({ isPlaying: false, sleepTimerMinutes: null, sleepTimerRemainingMs: null });
      showToast('Sleep timer ended \u2014 playback paused');
    } else {
      patch({ sleepTimerRemainingMs: remaining });
    }
  }, 1000);
}
