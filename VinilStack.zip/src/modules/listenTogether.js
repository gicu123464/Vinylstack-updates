import { state, patch, registerTracks, getTrack, showToast } from './state.js';
import * as actions from './actions.js';
import * as player from './player.js';
import { encodeEnvelope, decodeEnvelope, encodePayload, decodePayload } from './metroproto.js';

let socket = null;
let suppress = false;
const DEFAULT_SERVER_URL = 'wss://metroserverx.meowery.eu/ws';
let serverUrl = (() => {
  try {
    const saved = localStorage.getItem('vinylstack.listenServerUrl');
    return !saved || saved === 'ws://127.0.0.1:8787/ws' ? DEFAULT_SERVER_URL : saved;
  } catch (_) { return DEFAULT_SERVER_URL; }
})();
let sessionToken = null;
let roomStateChain = Promise.resolve();
let requestGeneration = 0;
let pingTimer = null;
let pingSequence = 0;
let serverClockOffsetMs = 0;
let lastServerRevision = 0;
let reconnectOnOpen = false;
let resyncOnOpen = false;

function send(type, payload = {}) {
  if (socket?.readyState !== WebSocket.OPEN) return;
  const body = encodePayload(type, payload);
  socket.send(encodeEnvelope(type, body, false));
}
function setStatus(status, extra = {}) { patch({ listenTogether: { ...state.listenTogether, status, ...extra } }); }
function trackFromProto(t) { return t ? { id:t.id,title:t.title,artist:t.artist||'Unknown artist',album:t.album,duration:t.duration||0,thumbnail:t.thumbnail||null } : null; }
function appStateFromProto(s) {
  return {
    track: trackFromProto(s.currentTrack), position: s.position || 0, playing: !!s.isPlaying,
    queueTracks: (s.queue || []).map(trackFromProto).filter(Boolean), volume: s.volume,
    lastUpdate: s.lastUpdate || 0, revision: s.revision || 0
  };
}

function handleMessage(bytes) {
  const env = decodeEnvelope(bytes);
  const payload = decodePayload(env.type, env.payload);
  const type = env.type;
  if (type === 'server_capabilities') return;
  if (type === 'pong') {
    if (payload.clientTime && payload.serverReceiveTime && payload.serverSendTime) {
      const receivedAt = Date.now();
      const roundTrip = receivedAt - payload.clientTime;
      if (roundTrip >= 0 && roundTrip < 10000) serverClockOffsetMs = ((payload.serverReceiveTime + payload.serverSendTime) / 2) - ((payload.clientTime + receivedAt) / 2);
    }
    return;
  }
  if (type === 'user_reconnected') { setStatus(state.listenTogether.host ? 'host' : 'guest', { users: [...(state.listenTogether.users || []).filter(u => u.id !== payload.userId), { id: payload.userId, username: payload.username, isConnected: true }] }); return; }
  if (type === 'buffer_wait' || type === 'buffer_complete') return;
  if (type === 'room_created') {
    lastServerRevision = 0;
    sessionToken = payload.sessionToken || null;
    setStatus('host',{roomCode:payload.roomCode,userId:payload.userId,sessionToken,hostId:payload.userId,users:[{id:payload.userId,username:'Host',isHost:true}],host:true});
    showToast(`Listen Together room created: ${payload.roomCode}`); broadcastTrack(); return;
  }
  if (type === 'join_request') {
    const users=[...(state.listenTogether.users||[]),{id:payload.userId,username:payload.username,pending:true}];
    setStatus('host',{users}); showToast(`${payload.username||'Someone'} wants to join your room`); return;
  }
  if (type === 'join_approved' || type === 'reconnected') {
    lastServerRevision = 0;
    sessionToken = payload.sessionToken || sessionToken;
    const rs = payload.state || {};
    lastServerRevision = rs.revision || 0;
    setStatus(payload.isHost ? 'host':'guest',{roomCode:payload.roomCode || rs.roomCode,userId:payload.userId,sessionToken,host:!!payload.isHost,hostId:rs.hostId,users:(rs.users||[]).map(u=>({id:u.userId,username:u.username,isHost:u.isHost,isConnected:u.isConnected}))});
    queueRoomState(appStateFromProto(rs));
    send('request_sync');
    showToast('Joined Listen Together'); return;
  }
  if (type === 'user_joined') { setStatus(state.listenTogether.host?'host':'guest',{users:[...(state.listenTogether.users||[]).filter(u=>u.id!==payload.userId),{id:payload.userId,username:payload.username}]}); return; }
  if (type === 'user_left' || type === 'user_disconnected') { setStatus(state.listenTogether.status,{users:(state.listenTogether.users||[]).filter(u=>u.id!==payload.userId)}); return; }
  if (type === 'sync_state') {
    if (payload.revision && payload.revision <= lastServerRevision) return;
    if (payload.revision) lastServerRevision = payload.revision;
    queueRoomState(appStateFromProto(payload)); return;
  }
  if (type === 'join_rejected' || type === 'error' || type === 'kicked') {
    const message = payload.message || payload.reason || 'Listen Together error';
    const currentStatus = state.listenTogether.status;
    setStatus(currentStatus === 'connecting' ? 'connected' : currentStatus, { error: `${payload.code ? `${payload.code}: ` : ''}${message}` });
    showToast(message, 'error'); return;
  }
  if (type === 'host_changed') {
    const host = payload.newHostId === state.listenTogether.userId;
    setStatus(host ? 'host' : 'guest', { hostId:payload.newHostId, host }); return;
  }
  if (type === 'sync_playback') {
    if (state.listenTogether.host) return;
    if (payload.revision && payload.revision <= lastServerRevision) return;
    if (payload.revision) lastServerRevision = payload.revision;
    const action=payload.action;
    if (payload.queueTitle && /unwanted client/i.test(payload.queueTitle)) {
      setStatus('guest', { error:'Metroserver policy has flagged this client. Ask the server owner to allow Vinylstack in the User-Agent policy.' });
    }
    const track=payload.trackInfo || getTrack(payload.trackId) || state.nowPlaying;
    const upcoming=payload.queue || state.queue.trackIds.map(id=>getTrack(id)).filter(t=>t&&t.id!==track?.id);
    queueRoomState({track,queueTracks:upcoming,position:typeof payload.position==='number'?payload.position:state.currentTime,lastUpdate:payload.serverTime||Date.now(),playing:action==='play'?true:action==='pause'||action==='change_track'?false:state.isPlaying,volume:typeof payload.volume==='number'?payload.volume:state.volume});
    return;
  }
}

function connect(url=serverUrl) {
  if (socket?.readyState === WebSocket.OPEN || socket?.readyState === WebSocket.CONNECTING) return;
  serverUrl=url||serverUrl; setStatus('connecting',{serverUrl});
  try { socket=new WebSocket(serverUrl); socket.binaryType='arraybuffer'; } catch(err){setStatus('disconnected',{error:err.message});showToast(`Could not connect: ${err.message}`,'error');return;}
  const ws=socket;
  ws.onopen=()=>{
    if(socket!==ws)return;
    setStatus('connected',{serverUrl,error:null});
    send('client_capabilities',{supportsProtobuf:true,supportsCompression:false,clientVersion:'Vinylstack/1.1'});
    if (reconnectOnOpen && sessionToken) { send('reconnect',{sessionToken}); reconnectOnOpen=false; }
    if (resyncOnOpen) { send('request_sync'); resyncOnOpen=false; }
    clearInterval(pingTimer);
    const ping = () => send('ping',{clientTime:Date.now(),sequence:++pingSequence});
    ping(); pingTimer=setInterval(ping,20000);
  };
  ws.onmessage=e=>{try{handleMessage(e.data instanceof ArrayBuffer?new Uint8Array(e.data):new Uint8Array(e.data))}catch(err){console.warn('metroproto decode failed',err);setStatus('connected',{error:`Could not read server response: ${err.message}`});showToast('Listen Together received an unreadable server response. Check that both users are using compatible app versions.','error');}};
  ws.onerror=()=>{if(socket!==ws)return;setStatus('disconnected',{error:`Could not reach ${serverUrl}`});showToast(`Listen Together couldn’t connect to ${serverUrl}. Check the server address and that the server is running.`,'error');};
  ws.onclose=()=>{if(socket!==ws)return;clearInterval(pingTimer);pingTimer=null;const neverConnected=ws.readyState!==WebSocket.OPEN&&state.listenTogether.status==='connecting';if(state.listenTogether.status!=='idle')setStatus('disconnected');socket=null;if(neverConnected)showToast(`Listen Together couldn’t reach ${serverUrl}. Check that the server is running and the address is correct.`,'error');};
}
export function configure(url){
  let next;
  try {
    const parsed = new URL(url.trim() || DEFAULT_SERVER_URL);
    if (parsed.protocol === 'http:') parsed.protocol = 'ws:';
    if (parsed.protocol === 'https:') parsed.protocol = 'wss:';
    if (!['ws:', 'wss:'].includes(parsed.protocol)) throw new Error('Use a ws:// or wss:// WebSocket address.');
    if (!parsed.pathname || parsed.pathname === '/') parsed.pathname = '/ws';
    next = parsed.toString();
  } catch (err) { showToast(err.message || 'Enter a valid Metroserver address.', 'error'); return; }
  if(socket){const old=socket;socket=null;try{old.close()}catch(_){}}
  clearInterval(pingTimer); pingTimer=null;
  requestGeneration++;
  serverUrl=next;
  try { localStorage.setItem('vinylstack.listenServerUrl', serverUrl); } catch (_) {}
  lastServerRevision=0; serverClockOffsetMs=0;
  sessionToken=null;
  patch({listenTogether:{...state.listenTogether,status:'idle',serverUrl,roomCode:null,users:[],pending:[],error:null}});
}
function sendAfterConnect(type,payload){
  const request=++requestGeneration;
  connect();
  const started=Date.now();
  const attempt=()=>{
    if(request!==requestGeneration)return;
    if(socket?.readyState===WebSocket.OPEN){send(type,payload);return;}
    if(state.listenTogether.status==='disconnected')return;
    if(!socket||socket.readyState===WebSocket.CLOSED||Date.now()-started>10000){
      setStatus('disconnected',{error:`Timed out connecting to ${serverUrl}`});
      showToast('Listen Together timed out. Verify the server address and make sure its server process is running.','error');
      return;
    }
    setTimeout(attempt,100);
  };
  attempt();
}
export function createRoom(username='Vinylstack user'){sendAfterConnect('create_room',{username});}
export function joinRoom(code,username='Vinylstack user'){sendAfterConnect('join_room',{roomCode:code.trim().toUpperCase(),username});}
export function approveUser(userId){send('approve_join',{userId});}
export function leaveRoom(){send('leave_room');disconnect();}
export function disconnect(reset=true){requestGeneration++;clearInterval(pingTimer);pingTimer=null;if(socket){try{socket.close()}catch(_){}socket=null}sessionToken=null;if(reset)patch({listenTogether:{...state.listenTogether,status:'idle',roomCode:null,users:[],pending:[]}});}
function roomState(){return {currentTrack:state.nowPlaying?{...state.nowPlaying,duration:state.duration||state.nowPlaying.duration||0}:null,position:state.currentTime||0,isPlaying:state.isPlaying,queue:(state.queue?.trackIds||[]).map(id=>getTrack(id)).filter(Boolean),volume:state.volume};}
function broadcast(action,extra={}){if(suppress||state.listenTogether.status!=='host')return;const capturedAtServerTime=Date.now()+serverClockOffsetMs;const current=roomState();send('playback_action',{action,...extra,trackId:state.nowPlaying?.id||'',trackInfo:current.currentTrack,queue:current.queue.filter(t=>t.id!==state.nowPlaying?.id),position:current.position,volume:state.volume,capturedAtServerTime});}
function broadcastTrack(){if(!state.nowPlaying)return;broadcast('change_track');if(state.isPlaying)broadcast('play',{position:state.currentTime||0});}
export function onLocalPlayback(action,extra={}){if(state.listenTogether.status==='host')broadcast(action,extra);}
function queueRoomState(s){roomStateChain=roomStateChain.then(()=>applyRoomState(s)).catch(err=>{console.warn('Listen Together state apply failed',err);showToast('Could not apply the room playback update.','error');});}
async function applyRoomState(s){if(!s)return;suppress=true;try{
  if(Array.isArray(s.queueTracks)){const tracks=[...(s.track?.id?[s.track]:[]),...s.queueTracks];registerTracks(tracks);const ids=[...new Set(tracks.map(t=>t.id).filter(Boolean))];patch({queue:{...state.queue,trackIds:ids,currentIndex:s.track?.id?Math.max(0,ids.indexOf(s.track.id)):-1}});}
  const t=s.track;if(t?.id){registerTracks(t);if(state.nowPlaying?.id!==t.id)await actions.playTrack(t,{fromQueue:true});}
  if(typeof s.position==='number'&&state.nowPlaying?.id===t?.id){const estimatedServerNow=Date.now()+serverClockOffsetMs;const drift=(s.playing&&s.lastUpdate)?Math.max(0,(estimatedServerNow-s.lastUpdate)/1000):0;const target=s.position+drift;if(Math.abs(state.currentTime-target)>1.15)player.seek(target);}
  if(typeof s.playing==='boolean'){if(s.playing&&!state.isPlaying){player.play();patch({isPlaying:true});}if(!s.playing&&state.isPlaying){player.pause();patch({isPlaying:false});}}
  if(typeof s.volume==='number')player.setVolume(s.volume);
}finally{setTimeout(()=>{suppress=false},100);}}
export function requestSync(){
  if (!sessionToken) { showToast('Join or create a room before resyncing playback.','warn'); return; }
  if (socket?.readyState === WebSocket.OPEN) send('request_sync');
  else { resyncOnOpen=true; reconnect(); }
}
export function reconnect(){
  clearInterval(pingTimer); pingTimer=null;
  if (socket) { const old=socket; socket=null; try { old.close(); } catch (_) {} }
  lastServerRevision=0;
  reconnectOnOpen=!!sessionToken;
  connect(serverUrl);
}
export function getServerUrl(){return serverUrl;}
