import { state, subscribe, patch, onTick } from './modules/state.js';
import * as actions from './modules/actions.js';
import * as player from './modules/player.js';
import * as visualizer from './modules/visualizer.js';
import { renderApp, renderPlaybackTick } from './modules/render.js';

const $ = (sel) => document.querySelector(sel);
let lastNonNowPlayingView = 'home';
let lastMediaTrackActionAt = 0;
let greetingTimer = null;

function scheduleGreetingRefresh() {
  clearTimeout(greetingTimer);
  const now = new Date();
  const boundaries = [5, 12, 17, 22].map((hour) => {
    const next = new Date(now);
    next.setHours(hour, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    return next.getTime();
  });
  const nextChange = Math.min(...boundaries);
  greetingTimer = setTimeout(() => {
    patch({ greetingRefresh: Date.now() });
    scheduleGreetingRefresh();
  }, Math.max(1000, nextChange - Date.now() + 50));
}

function skipFromMediaKey(direction) {
  const now = performance.now();
  if (now - lastMediaTrackActionAt < 250) return;
  lastMediaTrackActionAt = now;
  if (direction === 'next') actions.skipNext();
  else actions.skipPrev();
}

function wireStaticControls() {
  // sidebar nav
  document.getElementById('nav').addEventListener('click', (e) => {
    const btn = e.target.closest('.nav-item');
    if (!btn) return;
    patch({ view: btn.dataset.view, activePlaylistId: null });
  });
  document.querySelector('.sidebar-bottom').addEventListener('click', (e) => {
    const btn = e.target.closest('.nav-item');
    if (!btn) return;
    patch({ view: btn.dataset.view, activePlaylistId: null });
  });

  // top bar
  $('#global-search').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const q = e.target.value.replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
    if (!q) return;
    patch({ view: 'search', searchQuery: q, searchLoading: true });
    actions.queueSearch(q);
  });
  const playerMenu = $('#player-actions-menu');
  const playerMenuButton = $('#player-actions-trigger');
  const closePlayerMenu = () => { playerMenu.classList.remove('open'); playerMenuButton.setAttribute('aria-expanded', 'false'); };
  playerMenuButton.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = playerMenu.classList.toggle('open');
    playerMenuButton.setAttribute('aria-expanded', String(open));
  });
  playerMenu.addEventListener('click', (e) => e.stopPropagation());
  document.addEventListener('click', closePlayerMenu);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePlayerMenu(); });

  // transport controls
  $('#np-playpause').addEventListener('click', () => actions.togglePlayPause());
  $('#np-next').addEventListener('click', () => actions.skipNext());
  $('#np-prev').addEventListener('click', () => actions.skipPrev());
  $('#np-shuffle').addEventListener('click', () => actions.toggleShuffle());
  $('#np-repeat').addEventListener('click', () => actions.cycleRepeat());
  $('#np-radio').addEventListener('click', () => { actions.startRadio(); closePlayerMenu(); });
  $('#np-visualizer').addEventListener('click', () => { visualizer.open(); closePlayerMenu(); });
  $('#visualizer-close').addEventListener('click', visualizer.close);
  $('#speed-down').addEventListener('click', () => actions.setPlaybackRate(state.playbackRate - 0.05));
  $('#speed-up').addEventListener('click', () => actions.setPlaybackRate(state.playbackRate + 0.05));
  $('#speed-reset').addEventListener('click', () => actions.setPlaybackRate(1));
  $('#np-fullscreen').addEventListener('click', () => patch({ fullscreenPlayer: true }));
  $('#np-up-next').addEventListener('click', () => {
    if (state.view === 'now-playing') patch({ view: lastNonNowPlayingView });
    else { lastNonNowPlayingView = state.view; patch({ view: 'now-playing' }); }
  });
  $('#fullscreen-close').addEventListener('click', () => patch({ fullscreenPlayer: false }));
  $('#fullscreen-playpause').addEventListener('click', () => actions.togglePlayPause());
  $('#fullscreen-prev').addEventListener('click', () => actions.skipPrev());
  $('#fullscreen-next').addEventListener('click', () => actions.skipNext());
  $('#fullscreen-seek').addEventListener('input', (e) => { const v = Number(e.target.value); e.target.style.setProperty('--seek-progress', `${state.duration ? Math.min(100, v / state.duration * 100) : 0}%`); player.seek(v); actions.listenTogether.onLocalPlayback('seek', { position: v }); });
  // seek + volume
  $('#np-seekbar').addEventListener('input', (e) => { const v = Number(e.target.value); player.seek(v); actions.listenTogether.onLocalPlayback('seek', { position: v }); });
  $('#np-volume').addEventListener('input', (e) => actions.setVolume(Number(e.target.value)));

  // side panel
  const openTab = (tab) => {
    if (state.sidePanelOpen && state.sidePanelTab === tab) patch({ sidePanelOpen: false });
    else patch({ sidePanelOpen: true, sidePanelTab: tab });
  };
  $('#np-lyrics-toggle').addEventListener('click', () => openTab('lyrics'));
  $('#np-eq-toggle').addEventListener('click', () => { openTab('equalizer'); closePlayerMenu(); });
  $('#side-panel-close').addEventListener('click', () => patch({ sidePanelOpen: false }));
  document.querySelector('.side-panel-tabs').addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-tab]');
    if (btn) patch({ sidePanelTab: btn.dataset.tab });
  });

  // keyboard shortcuts (ignored while typing in a text field)
  window.addEventListener('keydown', (e) => {
    if (e.key === 'MediaTrackNext' || e.key === 'MediaNextTrack' || e.code === 'MediaTrackNext') { e.preventDefault(); if (!e.repeat) skipFromMediaKey('next'); return; }
    if (e.key === 'MediaTrackPrevious' || e.key === 'MediaPreviousTrack' || e.code === 'MediaTrackPrevious') { e.preventDefault(); if (!e.repeat) skipFromMediaKey('previous'); return; }
    const typing = ['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName);
    if (typing) return;
    if (e.code === 'Escape' && visualizer.isOpen()) { visualizer.close(); return; }
    if (e.code === 'Escape' && state.fullscreenPlayer) { patch({ fullscreenPlayer: false }); return; }
    if (e.code === 'Space') { e.preventDefault(); actions.togglePlayPause(); }
    else if (e.code === 'ArrowRight' && e.shiftKey) actions.skipNext();
    else if (e.code === 'ArrowLeft' && e.shiftKey) actions.skipPrev();
  });
}

async function main() {
  window.vinylstack.updates.onStatus((updateStatus) => patch({ updateStatus }));
  player.init($('#audio-el'));
  player.onEnded(async () => { await actions.extendRadioIfNeeded(); actions.skipNext(); });
  player.onProgress(() => { actions.extendRadioIfNeeded(); actions.prefetchNextTrack(); });
  player.onError(() => actions.handlePlaybackError());
  wireStaticControls();
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.setActionHandler('nexttrack', () => skipFromMediaKey('next'));
      navigator.mediaSession.setActionHandler('previoustrack', () => skipFromMediaKey('previous'));
      navigator.mediaSession.setActionHandler('play', () => actions.togglePlayPause());
      navigator.mediaSession.setActionHandler('pause', () => actions.togglePlayPause());
    } catch (error) { console.debug('System media controls are unavailable', error); }
  }

  subscribe((_current, changed) => renderApp(changed));
  onTick(() => { renderPlaybackTick(); actions.savePlaybackSession(); });
  window.addEventListener('pagehide', () => actions.savePlaybackSession(true));
  window.addEventListener('beforeunload', () => actions.savePlaybackSession(true));
  document.addEventListener('visibilitychange', () => { if (document.hidden) actions.savePlaybackSession(true); });
  scheduleGreetingRefresh();

  renderApp(); // initial paint before data arrives, so the shell isn't blank
  await actions.bootstrap();
  renderApp();
}

main();
