// store.js — tiny JSON-file persistence layer for the main process.
// One file per section so a corrupt/large section never risks the others.
const fs = require('fs');
const path = require('path');

const SECTIONS = ['library', 'playlists', 'favorites', 'settings', 'recents', 'queue'];

const DEFAULTS = {
  library: [],      // downloaded/local tracks: {id, title, artist, duration, thumbnail, filePath, addedAt}
  playlists: [],     // {id, name, trackIds: [], createdAt}
  favorites: [],     // array of track ids
  recents: [],       // array of track objects, most recent first, capped
  queue: { trackIds: [], currentIndex: -1, shuffle: false, repeat: 'off' },
  settings: {
    theme: 'dark',
    accent: '#dcbc90',
    visualEffects: true,
    downloadDir: null,       // filled in on first run to userData/downloads
    audioFormat: 'mp3',
    ytdlpPath: null,         // manual override if PATH lookup fails
    ffmpegPath: null,        // manual override if PATH lookup fails
    equalizer: { preset: 'flat', bands: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
    volume: 1,
    excludeVideos: false,
    visualizerResponsiveness: 75,
    visualizerColor: '#dcbc90',
    visualizerBands: 120,
    audioQuality: 'medium',
    sleepTimerMinutes: null,
    autoUpdate: false
  }
};

class Store {
  constructor(baseDir) {
    this.baseDir = baseDir;
    if (!fs.existsSync(this.baseDir)) fs.mkdirSync(this.baseDir, { recursive: true });
    this.cache = {};
    for (const section of SECTIONS) this.cache[section] = this._load(section);
  }

  _filePath(section) {
    return path.join(this.baseDir, `${section}.json`);
  }

  _load(section) {
    const file = this._filePath(section);
    try {
      if (fs.existsSync(file)) {
        const raw = fs.readFileSync(file, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.error(`[store] failed to read ${section}, falling back to default:`, err.message);
    }
    return structuredClone(DEFAULTS[section]);
  }

  get(section) {
    return this.cache[section];
  }

  set(section, value) {
    this.cache[section] = value;
    const file = this._filePath(section);
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf-8');
    fs.renameSync(tmp, file);
    return this.cache[section];
  }
}

module.exports = { Store, SECTIONS, DEFAULTS };
