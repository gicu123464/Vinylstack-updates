const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('vinylstack', {
  store: {
    get: (section) => ipcRenderer.invoke('store:get', section),
    set: (section, value) => ipcRenderer.invoke('store:set', section, value)
  },
  binaries: {
    check: () => ipcRenderer.invoke('binaries:check')
  },
  updates: {
    getState: () => ipcRenderer.invoke('updates:getState'),
    check: () => ipcRenderer.invoke('updates:check'),
    download: () => ipcRenderer.invoke('updates:download'),
    install: () => ipcRenderer.invoke('updates:install'),
    setAuto: (enabled) => ipcRenderer.invoke('updates:setAuto', enabled),
    onStatus: (callback) => {
      const listener = (_event, value) => callback(value);
      ipcRenderer.on('updates:status', listener);
      return () => ipcRenderer.removeListener('updates:status', listener);
    }
  },
  ytdlp: {
    search: (query, limit, options) => ipcRenderer.invoke('ytdlp:search', query, limit, options),
    resolve: (videoId) => ipcRenderer.invoke('ytdlp:resolve', videoId),
    importPlaylist: (url) => ipcRenderer.invoke('ytdlp:importPlaylist', url),
    download: (videoId, meta) => ipcRenderer.invoke('ytdlp:download', videoId, meta)
  },
  lyrics: {
    fetch: (title, artist, duration) => ipcRenderer.invoke('lyrics:fetch', title, artist, duration)
  },
  fs: {
    chooseDownloadDir: () => ipcRenderer.invoke('dialog:chooseDownloadDir'),
    openPath: (p) => ipcRenderer.invoke('shell:openPath', p),
    removeLibraryFile: (trackId) => ipcRenderer.invoke('library:removeFile', trackId),
    locateBinary: (type) => ipcRenderer.invoke('dialog:locateBinary', type)
  }
});
